import { useEffect } from 'react'
import { Navigate, Route, Routes } from 'react-router'
import { Toaster, toast } from 'sonner'
import { useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { usePlayback } from '@/hooks/usePlayback'
import { Header } from '@/components/Header'
import { PresentationMode } from '@/components/PresentationMode'
import { Workspace } from '@/pages/Workspace'
import { LibraryPage } from '@/pages/LibraryPage'
import { TemplatesPage } from '@/pages/TemplatesPage'
import { SettingsPage } from '@/pages/SettingsPage'

export default function App() {
  const t = useT()
  const initialized = useAppStore(state => state.initialized)
  const updatedAt = useAppStore(state => state.plan.updatedAt)
  const language = useAppStore(state => state.settings.language)
  const theme = useAppStore(state => state.settings.theme)
  const presentation = useAppStore(state => state.playback.presentation)
  const saveStatus = useAppStore(state => state.saveStatus)
  usePlayback()

  useEffect(() => { void useAppStore.getState().initialize() }, [])
  useEffect(() => {
    const handler = (event: Event) => {
      const update = (event as CustomEvent<(reload?: boolean) => Promise<void>>).detail
      toast(t('messages.updateReady'), { action: { label: t('messages.reload'), onClick: () => void update(true) } })
    }
    window.addEventListener('coach-pwa-update', handler)
    return () => window.removeEventListener('coach-pwa-update', handler)
  }, [t])
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr'
    document.documentElement.lang = language
    document.documentElement.dataset.theme = theme
  }, [language, theme])
  useEffect(() => {
    if (!initialized) return
    const timer = window.setTimeout(() => { void useAppStore.getState().saveNow().catch(() => undefined) }, 550)
    return () => window.clearTimeout(timer)
  }, [updatedAt, initialized])
  useEffect(() => {
    const beforeUnload = (event: BeforeUnloadEvent) => {
      if (saveStatus === 'saving' || saveStatus === 'failed') { event.preventDefault(); event.returnValue = '' }
    }
    window.addEventListener('beforeunload', beforeUnload)
    return () => window.removeEventListener('beforeunload', beforeUnload)
  }, [saveStatus])

  return <div className="app-root">
    <Header />
    {!initialized && <div className="startup-indicator"><span />{t('messages.startup')}</div>}
    <Routes>
      <Route path="/" element={<Workspace />} />
      <Route path="/library" element={<LibraryPage />} />
      <Route path="/templates" element={<TemplatesPage />} />
      <Route path="/set-pieces" element={<TemplatesPage setPieces />} />
      <Route path="/settings" element={<SettingsPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
    {presentation && <PresentationMode />}
    <Toaster position="bottom-center" richColors closeButton toastOptions={{ className: 'app-toast' }} />
  </div>
}

