import { create } from 'zustand'
import type { ApplicationSettings, CustomTemplate, DrawingType, Formation, SaveStatus, TacticalDrawing, TacticalPlan, TacticalPlayer, TacticalSequence, TacticalStep, TeamId, Tool, TransitionSettings } from '@/types'
import { blankStep, createPlan, createStep, defaultSettings, drawingDefaults, playersForFormation } from '@/data/factory'
import { getFormation } from '@/data/formations'
import { clone, uid } from '@/lib/utils'
import { db, deletePlanTransaction, savePlanTransaction } from '@/services/database'

export const activeSequence = (plan: TacticalPlan) => plan.sequences.find(sequence => sequence.id === plan.activeSequenceId) ?? plan.sequences[0]
export const activeStep = (plan: TacticalPlan, index: number) => {
  const sequence = activeSequence(plan)
  return sequence.steps[Math.max(0, Math.min(index, sequence.steps.length - 1))]
}

interface PlaybackState {
  playing: boolean
  progress: number
  speed: number
  continuous: boolean
  presentation: boolean
}

interface AppState {
  plan: TacticalPlan
  plans: TacticalPlan[]
  customFormations: Formation[]
  customTemplates: CustomTemplate[]
  settings: ApplicationSettings
  initialized: boolean
  saveStatus: SaveStatus
  tool: Tool
  stepIndex: number
  selectedPlayerIds: string[]
  selectedDrawingId: string | null
  past: TacticalPlan[]
  future: TacticalPlan[]
  playback: PlaybackState
  initialize: () => Promise<void>
  newPlan: (name?: string, formation?: string) => TacticalPlan
  loadPlan: (id: string) => Promise<void>
  setPlan: (plan: TacticalPlan) => void
  saveNow: () => Promise<void>
  deletePlan: (id: string) => Promise<void>
  saveAsNew: (name: string) => TacticalPlan
  setTool: (tool: Tool) => void
  setSettings: (settings: Partial<ApplicationSettings>) => void
  updateMetadata: (patch: Partial<TacticalPlan>) => void
  checkpoint: () => void
  undo: () => void
  redo: () => void
  selectPlayers: (ids: string[]) => void
  selectDrawing: (id: string | null) => void
  applyFormation: (teamId: TeamId, formationId: string) => void
  toggleTeam: (teamId: TeamId) => void
  addPlayer: (teamId: TeamId) => void
  updatePlayer: (id: string, patch: Partial<TacticalPlayer>, record?: boolean) => void
  movePlayers: (ids: string[], dx: number, dy: number) => void
  duplicatePlayer: (id: string) => void
  deletePlayer: (id: string) => void
  updateBall: (patch: Partial<TacticalPlan['sequences'][number]['steps'][number]['ball']>, record?: boolean) => void
  addDrawing: (type: DrawingType, points: TacticalDrawing['points']) => TacticalDrawing
  updateDrawing: (id: string, patch: Partial<TacticalDrawing>, record?: boolean) => void
  deleteDrawing: (id: string) => void
  duplicateDrawing: (id: string) => void
  setStepIndex: (index: number) => void
  addStep: (mode: 'copy' | 'blank') => void
  duplicateStep: () => void
  deleteStep: () => void
  resetStep: () => void
  updateStep: (patch: Partial<TacticalStep>) => void
  updateTransition: (patch: Partial<TransitionSettings>) => void
  updatePlayerPath: (playerId: string, patch: Partial<TransitionSettings['playerPaths'][string]>) => void
  updateBallPath: (patch: Partial<TransitionSettings['ballPath']>) => void
  reorderSteps: (from: number, to: number) => void
  newSequence: (name: string) => void
  duplicateSequence: () => void
  setActiveSequence: (id: string) => void
  setPlayback: (patch: Partial<PlaybackState>) => void
  saveCustomFormation: (name: string) => Promise<void>
  saveCurrentTemplate: (name: string) => Promise<void>
}

const readLocalSettings = (): ApplicationSettings => {
  try { return { ...defaultSettings, ...JSON.parse(localStorage.getItem('coach-settings') ?? '{}') } } catch { return defaultSettings }
}
const freshPlan = () => createPlan()

function mutateStep(plan: TacticalPlan, index: number, recipe: (step: TacticalStep) => void) {
  const sequence = activeSequence(plan)
  const step = sequence.steps[index]
  if (step) recipe(step)
}

export const useAppStore = create<AppState>((set, get) => {
  const commit = (recipe: (plan: TacticalPlan) => void, record = true) => {
    const current = get().plan
    const next = clone(current)
    recipe(next)
    next.updatedAt = new Date().toISOString()
    set(state => ({
      plan: next,
      past: record ? [...state.past.slice(-59), clone(current)] : state.past,
      future: record ? [] : state.future,
      saveStatus: 'saving',
    }))
  }
  const stop = () => ({ playing: false, progress: 0 })

  return {
    plan: freshPlan(), plans: [], customFormations: [], customTemplates: [], settings: readLocalSettings(), initialized: false,
    saveStatus: 'idle', tool: 'select', stepIndex: 0, selectedPlayerIds: [], selectedDrawingId: null, past: [], future: [],
    playback: { playing: false, progress: 0, speed: 1, continuous: true, presentation: false },

    initialize: async () => {
      try {
        const [plans, customFormations, customTemplates, settingRow] = await Promise.all([
          db.plans.toArray(), db.formations.filter(item => item.custom).toArray(), db.templates.toArray(), db.settings.get('application'),
        ])
        const settings = { ...get().settings, ...settingRow?.value }
        const latest = [...plans].sort((a, b) => b.lastOpenedAt.localeCompare(a.lastOpenedAt))[0]
        set({ plans, customFormations, customTemplates, settings, plan: latest ?? get().plan, initialized: true, saveStatus: 'idle' })
        localStorage.setItem('coach-settings', JSON.stringify(settings))
      } catch {
        set({ initialized: true, saveStatus: 'unavailable' })
      }
    },
    newPlan: (name = 'New tactical plan', formation = '4-3-3') => {
      const plan = createPlan(name, formation)
      set({ plan, stepIndex: 0, past: [], future: [], selectedPlayerIds: [], selectedDrawingId: null, playback: { ...get().playback, ...stop(), presentation: false }, saveStatus: 'saving' })
      return plan
    },
    loadPlan: async id => {
      const plan = await db.plans.get(id)
      if (!plan) throw new Error('Plan not found')
      const opened = { ...clone(plan), lastOpenedAt: new Date().toISOString() }
      await db.plans.put(opened)
      set({ plan: opened, stepIndex: 0, past: [], future: [], selectedPlayerIds: [], selectedDrawingId: null, playback: { ...get().playback, ...stop(), presentation: false }, saveStatus: 'saved' })
    },
    setPlan: plan => set({ plan: clone(plan), stepIndex: 0, past: [], future: [], selectedPlayerIds: [], selectedDrawingId: null, playback: { ...get().playback, ...stop(), presentation: false }, saveStatus: 'saving' }),
    saveNow: async () => {
      set({ saveStatus: 'saving' })
      try {
        await savePlanTransaction(get().plan)
        const plans = await db.plans.toArray()
        set({ saveStatus: 'saved', plans })
      } catch (error) {
        set({ saveStatus: 'failed' })
        throw error
      }
    },
    deletePlan: async id => {
      await deletePlanTransaction(id)
      const plans = await db.plans.toArray()
      if (get().plan.id === id) {
        set({ plans, plan: plans[0] ?? createPlan(), stepIndex: 0, past: [], future: [], selectedPlayerIds: [], selectedDrawingId: null, saveStatus: 'idle' })
      } else set({ plans })
    },
    saveAsNew: name => {
      const now = new Date().toISOString()
      const plan = { ...clone(get().plan), id: uid('plan'), name, createdAt: now, updatedAt: now, lastOpenedAt: now }
      set({ plan, past: [], future: [], saveStatus: 'saving' })
      return plan
    },
    setTool: tool => set({ tool, selectedDrawingId: null }),
    setSettings: patch => {
      const settings = { ...get().settings, ...patch }
      set({ settings })
      try { localStorage.setItem('coach-settings', JSON.stringify(settings)); void db.settings.put({ id: 'application', value: settings }) } catch { /* local settings remain available in memory */ }
    },
    updateMetadata: patch => commit(plan => Object.assign(plan, patch)),
    checkpoint: () => set(state => ({ past: [...state.past.slice(-59), clone(state.plan)], future: [] })),
    undo: () => {
      const { past, plan, future } = get()
      const previous = past.at(-1)
      if (!previous) return
      set({ plan: clone(previous), past: past.slice(0, -1), future: [clone(plan), ...future].slice(0, 60), playback: { ...get().playback, ...stop() }, saveStatus: 'saving' })
    },
    redo: () => {
      const { past, plan, future } = get()
      const next = future[0]
      if (!next) return
      set({ plan: clone(next), past: [...past, clone(plan)].slice(-60), future: future.slice(1), playback: { ...get().playback, ...stop() }, saveStatus: 'saving' })
    },
    selectPlayers: ids => set({ selectedPlayerIds: ids, selectedDrawingId: null }),
    selectDrawing: id => set({ selectedDrawingId: id, selectedPlayerIds: [] }),
    applyFormation: (teamId, formationId) => commit(plan => {
      const formation = getFormation(formationId, get().customFormations)
      mutateStep(plan, get().stepIndex, step => {
        const others = step.players.filter(player => player.teamId !== teamId)
        const existing = step.players.filter(player => player.teamId === teamId)
        const positioned = formation.positions.map((position, index) => ({
          ...(existing[index] ?? { id: uid('player'), teamId, name: '', locked: false, visible: true, trail: true }),
          number: position.number, position: position.position, x: teamId === 'A' ? position.x : 1 - position.x, y: position.y,
        }))
        step.players = [...others, ...positioned]
      })
      if (teamId === 'A') plan.formation = formationId
      const team = teamId === 'A' ? plan.teamA : plan.teamB
      team.formation = formationId
      if (teamId === 'B') team.visible = true
    }),
    toggleTeam: teamId => commit(plan => {
      const team = teamId === 'A' ? plan.teamA : plan.teamB
      team.visible = !team.visible
      if (teamId === 'B' && team.visible) mutateStep(plan, get().stepIndex, step => {
        if (!step.players.some(player => player.teamId === 'B')) step.players.push(...playersForFormation(team.formation, 'B', get().customFormations))
      })
    }),
    addPlayer: teamId => commit(plan => {
      if (teamId === 'B' && !plan.teamB.visible) plan.teamB.visible = true
      mutateStep(plan, get().stepIndex, step => {
        const number = Math.min(99, Math.max(0, ...step.players.filter(p => p.teamId === teamId).map(p => p.number)) + 1)
        step.players.push({ id: uid('player'), teamId, number, name: '', position: 'SUB', x: teamId === 'A' ? .4 : .6, y: .5, locked: false, visible: true, trail: true })
      })
    }),
    updatePlayer: (id, patch, record = true) => commit(plan => mutateStep(plan, get().stepIndex, step => {
      const player = step.players.find(item => item.id === id)
      if (player && (!player.locked || Object.keys(patch).every(key => key === 'locked'))) Object.assign(player, patch)
    }), record),
    movePlayers: (ids, dx, dy) => commit(plan => mutateStep(plan, get().stepIndex, step => {
      step.players.forEach(player => {
        if (ids.includes(player.id) && !player.locked) {
          player.x = Math.max(0, Math.min(1, player.x + dx)); player.y = Math.max(0, Math.min(1, player.y + dy))
        }
      })
    }), false),
    duplicatePlayer: id => commit(plan => mutateStep(plan, get().stepIndex, step => {
      const player = step.players.find(item => item.id === id)
      if (player) step.players.push({ ...clone(player), id: uid('player'), number: Math.min(99, player.number + 1), x: Math.min(.98, player.x + .035), y: Math.min(.98, player.y + .035), locked: false })
    })),
    deletePlayer: id => commit(plan => mutateStep(plan, get().stepIndex, step => { step.players = step.players.filter(player => player.id !== id) })),
    updateBall: (patch, record = true) => commit(plan => mutateStep(plan, get().stepIndex, step => Object.assign(step.ball, patch)), record),
    addDrawing: (type, points) => {
      const drawing: TacticalDrawing = { id: uid('drawing'), type, points: clone(points), ...drawingDefaults(type), opacity: 1, label: type === 'text' ? 'Coaching note' : '', locked: false }
      commit(plan => mutateStep(plan, get().stepIndex, step => {
        step.drawings.push(drawing)
        if (type === 'ballPath' && points.length >= 2) {
          const end = points.at(-1)!
          step.transition.ballPath = { ...step.transition.ballPath, curve: type === 'ballPath' && points.length > 2 ? .2 : 0 }
          step.ball.x = end.x; step.ball.y = end.y
        }
      }))
      set({ selectedDrawingId: drawing.id })
      return drawing
    },
    updateDrawing: (id, patch, record = true) => commit(plan => mutateStep(plan, get().stepIndex, step => {
      const drawing = step.drawings.find(item => item.id === id)
      if (drawing && !drawing.locked) Object.assign(drawing, patch)
    }), record),
    deleteDrawing: id => { commit(plan => mutateStep(plan, get().stepIndex, step => { step.drawings = step.drawings.filter(item => item.id !== id) })); set({ selectedDrawingId: null }) },
    duplicateDrawing: id => commit(plan => mutateStep(plan, get().stepIndex, step => {
      const drawing = step.drawings.find(item => item.id === id)
      if (drawing) step.drawings.push({ ...clone(drawing), id: uid('drawing'), points: drawing.points.map(point => ({ x: Math.min(.98, point.x + .025), y: Math.min(.98, point.y + .025) })), locked: false })
    })),
    setStepIndex: index => {
      const length = activeSequence(get().plan).steps.length
      set({ stepIndex: Math.max(0, Math.min(index, length - 1)), playback: { ...get().playback, ...stop() }, selectedPlayerIds: [], selectedDrawingId: null })
    },
    addStep: mode => {
      const { plan, stepIndex } = get()
      const current = activeStep(plan, stepIndex)
      const step = mode === 'copy' ? { ...clone(current), id: uid('step'), title: `${current.title} · ${stepIndex + 2}` } : blankStep()
      commit(draft => activeSequence(draft).steps.splice(stepIndex + 1, 0, step))
      set({ stepIndex: stepIndex + 1, playback: { ...get().playback, ...stop() } })
    },
    duplicateStep: () => get().addStep('copy'),
    deleteStep: () => {
      const { plan, stepIndex } = get()
      if (activeSequence(plan).steps.length <= 1) return
      commit(draft => activeSequence(draft).steps.splice(stepIndex, 1))
      set({ stepIndex: Math.max(0, stepIndex - 1), playback: { ...get().playback, ...stop() } })
    },
    resetStep: () => commit(plan => {
      const sequence = activeSequence(plan)
      const previous = sequence.steps[get().stepIndex - 1]
      const replacement = previous ? { ...clone(previous), id: sequence.steps[get().stepIndex].id, title: sequence.steps[get().stepIndex].title, instructions: sequence.steps[get().stepIndex].instructions } : createStep()
      sequence.steps[get().stepIndex] = replacement
    }),
    updateStep: patch => commit(plan => mutateStep(plan, get().stepIndex, step => Object.assign(step, patch))),
    updateTransition: patch => commit(plan => mutateStep(plan, get().stepIndex, step => Object.assign(step.transition, patch))),
    updatePlayerPath: (playerId, patch) => commit(plan => mutateStep(plan, get().stepIndex, step => {
      const current = step.transition.playerPaths[playerId] ?? { playerId, delay: 0, duration: step.transition.duration, easing: step.transition.easing, curve: 0 }
      step.transition.playerPaths[playerId] = { ...current, ...patch }
    })),
    updateBallPath: patch => commit(plan => mutateStep(plan, get().stepIndex, step => Object.assign(step.transition.ballPath, patch))),
    reorderSteps: (from, to) => commit(plan => {
      const steps = activeSequence(plan).steps
      if (to < 0 || to >= steps.length || from === to) return
      const [step] = steps.splice(from, 1)
      steps.splice(to, 0, step)
    }),
    newSequence: name => {
      const current = activeStep(get().plan, get().stepIndex)
      const sequence: TacticalSequence = { id: uid('sequence'), name, category: 'custom', steps: [{ ...clone(current), id: uid('step'), title: 'Initial shape' }] }
      commit(plan => { plan.sequences.push(sequence); plan.activeSequenceId = sequence.id })
      set({ stepIndex: 0 })
    },
    duplicateSequence: () => {
      const source = activeSequence(get().plan)
      const sequence = { ...clone(source), id: uid('sequence'), name: `${source.name} copy`, steps: source.steps.map(step => ({ ...clone(step), id: uid('step') })) }
      commit(plan => { plan.sequences.push(sequence); plan.activeSequenceId = sequence.id })
      set({ stepIndex: 0 })
    },
    setActiveSequence: id => { commit(plan => { plan.activeSequenceId = id }, false); set({ stepIndex: 0, playback: { ...get().playback, ...stop() } }) },
    setPlayback: patch => set({ playback: { ...get().playback, ...patch } }),
    saveCustomFormation: async name => {
      const players = activeStep(get().plan, get().stepIndex).players.filter(player => player.teamId === 'A').slice(0, 11)
      const formation: Formation = { id: uid('custom-formation'), name, custom: true, positions: players.map(player => ({ x: player.x, y: player.y, number: player.number, position: player.position })) }
      await db.formations.put(formation)
      set({ customFormations: await db.formations.filter(item => item.custom).toArray() })
    },
    saveCurrentTemplate: async name => {
      const template: CustomTemplate = { id: uid('template'), name, createdAt: new Date().toISOString(), sequence: clone(activeSequence(get().plan)) }
      await db.templates.put(template)
      set({ customTemplates: await db.templates.toArray() })
    },
  }
})
