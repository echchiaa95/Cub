import type { ApplicationSettings, Formation, TacticalDrawing, TacticalPlan, TacticalPlayer, TacticalSequence, TacticalStep, TeamId, TransitionSettings } from '@/types'
import { clone, uid } from '@/lib/utils'
import { getFormation, formationPresets } from './formations'

export const defaultSettings: ApplicationSettings = {
  language: 'en', theme: 'dark', orientation: 'landscape', attackDirection: 'ltr', pitchView: 'full',
  showGrid: false, showLabels: true, showTrails: true, showLegend: true, showPaths: true,
  showTeamLabels: true, markerSize: 22, markerShape: 'circle', reducedMotion: false,
}

export const defaultTransition = (duration = 1800): TransitionSettings => ({
  duration, easing: 'easeInOut', instant: false, playerPaths: {},
  ballPath: { delay: 0, duration, easing: 'easeInOut', curve: 0, showPath: true },
})

export const playersForFormation = (formationId: string, teamId: TeamId, customFormations: Formation[] = []): TacticalPlayer[] => {
  const formation = getFormation(formationId, customFormations)
  return formation.positions.map(position => ({
    id: uid('player'), teamId, number: position.number, name: '', position: position.position,
    x: teamId === 'A' ? position.x : 1 - position.x, y: position.y,
    locked: false, visible: true, trail: true,
  }))
}

export const drawingDefaults = (type: TacticalDrawing['type']): Pick<TacticalDrawing, 'color' | 'width' | 'dash' | 'arrow' | 'fill' | 'fillOpacity'> => {
  if (type === 'pass' || type === 'ballPath') return { color: '#f8fafc', width: 4, dash: '10 8', arrow: true, fill: 'none', fillOpacity: 0 }
  if (['defensiveMove', 'defensiveLine', 'offsideLine'].includes(type)) return { color: '#fb7185', width: 4, dash: type === 'offsideLine' ? '14 8' : '', arrow: type === 'defensiveMove', fill: 'none', fillOpacity: 0 }
  if (type === 'press') return { color: '#fbbf24', width: 5, dash: '4 6', arrow: true, fill: 'none', fillOpacity: 0 }
  if (['zone', 'circle', 'rectangle', 'polygon'].includes(type)) return { color: '#fbbf24', width: 3, dash: '', arrow: false, fill: '#fbbf24', fillOpacity: .16 }
  return { color: '#bef264', width: 4, dash: type === 'dashedArrow' ? '12 8' : '', arrow: !['freehand', 'text', 'number'].includes(type), fill: 'none', fillOpacity: 0 }
}

export function createStep(title = 'Initial shape', players: TacticalPlayer[] = [], instructions = ''): TacticalStep {
  return {
    id: uid('step'), title, instructions, players: clone(players), ball: { x: .5, y: .5, visible: true, trail: true },
    drawings: [], duration: 2200, transition: defaultTransition(1800),
  }
}

export function createPlan(name = 'New tactical plan', formation = '4-3-3'): TacticalPlan {
  const now = new Date().toISOString()
  const players = playersForFormation(formation, 'A')
  const step = createStep('Initial shape', players, 'Set the starting structure, then add a step to animate the next movement.')
  const sequence: TacticalSequence = { id: uid('sequence'), name: 'Main sequence', category: 'attacking', steps: [step] }
  return {
    schemaVersion: 1, id: uid('plan'), name, description: '', category: 'attacking', formation,
    teamA: { id: 'A', name: 'Home', color: '#22d3ee', textColor: '#082f49', visible: true, formation },
    teamB: { id: 'B', name: 'Opponent', color: '#fb7185', textColor: '#4c0519', visible: false, formation: '4-4-2' },
    opponentName: '', matchLabel: '', sequences: [sequence], activeSequenceId: sequence.id,
    createdAt: now, updatedAt: now, favorite: false, lastOpenedAt: now,
  }
}

export const blankStep = () => ({ ...createStep('Blank step', []), ball: { x: .5, y: .5, visible: true, trail: true } })
export const defaultFormationList = () => clone(formationPresets)
