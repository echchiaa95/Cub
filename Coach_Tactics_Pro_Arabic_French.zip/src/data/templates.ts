import type { ScenarioTemplate, TacticalDrawing, TacticalPlan, TacticalPlayer, TacticalStep } from '@/types'
import { clone, uid } from '@/lib/utils'
import { createPlan, createStep, defaultTransition, drawingDefaults, playersForFormation } from './factory'

const names = {
  attacking: [
    'buildUpGoalkeeper', 'playingOutBack', 'midfieldOverload', 'wingOverload', 'switchingPlay',
    'positionalAttack', 'thirdManCombination', 'oneTwoPassing', 'overlappingRuns', 'underlappingRuns',
    'betweenLines', 'crossingFinishing', 'farPostMovement',
  ],
  defensive: [
    'highPress', 'midBlock', 'lowBlock', 'compactShape', 'pressingTriggers', 'coverShadow',
    'defensiveLineMovement', 'shiftingToBall', 'protectCentral', 'pressingTraps', 'markingCovering', 'defendingCrosses',
  ],
  transitions: ['attackingTransition', 'defensiveTransition', 'counterattack', 'counterPressing', 'recoveryRuns', 'fastProgression'],
  setPieces: ['shortCorner', 'nearPostCorner', 'farPostCorner', 'decoyCorner', 'zonalCorner', 'manMarkingCorner', 'directFreeKick', 'crossingFreeKick', 'defensiveWall', 'throwInCombination', 'penaltyRoutine'],
} as const

const patternFor = (category: string, id: string): ScenarioTemplate['pattern'] => {
  if (id.toLowerCase().includes('corner')) return 'corner'
  if (id.toLowerCase().includes('freekick') || id === 'defensiveWall') return 'freeKick'
  if (id === 'throwInCombination') return 'throwIn'
  if (id === 'penaltyRoutine') return 'penalty'
  if (category === 'defensive') return ['highPress', 'pressingTriggers', 'coverShadow', 'pressingTraps', 'counterPressing'].includes(id) ? 'press' : 'block'
  if (category === 'transitions') return 'transition'
  if (['wingOverload', 'switchingPlay', 'overlappingRuns', 'underlappingRuns', 'crossingFinishing', 'farPostMovement'].includes(id)) return 'wide'
  if (['midfieldOverload', 'thirdManCombination', 'oneTwoPassing', 'betweenLines', 'positionalAttack'].includes(id)) return 'central'
  return 'buildUp'
}

export const scenarioTemplates: ScenarioTemplate[] = Object.entries(names).flatMap(([category, ids]) =>
  ids.map(id => ({
    id, nameKey: `templates.${id}`, descriptionKey: `templateDescriptions.${patternFor(category, id)}`,
    category: category as ScenarioTemplate['category'], pitchView: category === 'setPieces' ? 'penaltyArea' : 'full',
    pattern: patternFor(category, id),
  })),
)

const makeDrawing = (type: TacticalDrawing['type'], points: TacticalDrawing['points'], label = ''): TacticalDrawing => ({
  id: uid('drawing'), type, points, ...drawingDefaults(type), opacity: 1, label, locked: false,
})

const arrangeSetPiece = (players: TacticalPlayer[], pattern: ScenarioTemplate['pattern']) => players.map(player => {
  if (pattern === 'penalty') {
    const index = Number(player.number)
    return { ...player, x: player.teamId === 'A' ? (index === 9 ? .86 : .76 + (index % 3) * .025) : .73 + (index % 4) * .025, y: index === 1 ? .5 : .22 + (index % 7) * .09, visible: true }
  }
  if (pattern === 'throwIn') {
    const index = player.number
    return { ...player, x: .55 + (index % 4) * .07, y: player.teamId === 'A' ? .08 + (index % 5) * .07 : .15 + (index % 5) * .07, visible: true }
  }
  const index = player.number
  if (player.position === 'GK') return { ...player, x: player.teamId === 'A' ? .06 : .96, y: .5, visible: true }
  return {
    ...player,
    x: player.teamId === 'A' ? .77 + (index % 4) * .04 : .82 + (index % 4) * .03,
    y: .2 + (index % 7) * .1,
    visible: true,
  }
})

export function instantiateTemplate(template: ScenarioTemplate, t: (key: string) => string): TacticalPlan {
  const plan = createPlan(t(template.nameKey), template.category === 'setPieces' ? '4-3-3' : template.category === 'defensive' ? '4-4-2' : '4-3-3')
  plan.category = template.category
  plan.description = t(template.descriptionKey)
  plan.teamB.visible = template.category !== 'attacking' || template.pattern === 'wide'
  let players = [...playersForFormation(plan.formation, 'A'), ...playersForFormation('4-4-2', 'B')]
  if (template.category === 'setPieces') players = arrangeSetPiece(players, template.pattern)
  const first = createStep(t('steps.startingShape'), players, t(template.descriptionKey))
  first.ball = template.pattern === 'corner' ? { x: .985, y: .02, visible: true, trail: true }
    : template.pattern === 'penalty' ? { x: .89, y: .5, visible: true, trail: true }
      : template.pattern === 'freeKick' ? { x: .72, y: .5, visible: true, trail: true }
        : template.pattern === 'throwIn' ? { x: .62, y: .01, visible: true, trail: true }
          : { x: .08, y: .5, visible: true, trail: true }
  const second = clone(first) as TacticalStep
  second.id = uid('step'); second.title = t('steps.movement'); second.transition = defaultTransition(2000)
  const third = clone(first) as TacticalStep
  third.id = uid('step'); third.title = t('steps.finish'); third.transition = defaultTransition(1800)

  if (template.category === 'setPieces') {
    second.players = second.players.map((p, i) => ({ ...p, x: Math.min(.94, p.x + (p.teamId === 'A' ? .035 : -.018)), y: Math.max(.12, Math.min(.88, p.y + ((i % 3) - 1) * .06)) }))
    third.ball = { ...first.ball, x: .88, y: .34 }
    third.players = third.players.map(p => p.number === 9 && p.teamId === 'A' ? { ...p, x: .92, y: .42 } : p)
    second.drawings = [makeDrawing(template.pattern === 'corner' ? 'curvedArrow' : 'pass', [first.ball, { x: .91, y: .5 }, third.ball], t('legend.ballMovement'))]
    second.transition.ballPath = { delay: 250, duration: 1200, easing: 'easeInOut', curve: template.pattern === 'corner' ? .25 : 0, showPath: true }
  } else {
    const shift = template.pattern === 'press' || template.pattern === 'transition' ? .14 : template.pattern === 'block' ? -.05 : .09
    second.players = second.players.map((p, i) => ({ ...p, x: Math.max(.04, Math.min(.96, p.x + (p.teamId === 'A' ? shift : -shift * .35))), y: Math.max(.08, Math.min(.92, p.y + ((i % 3) - 1) * .035)) }))
    third.players = third.players.map(p => ({ ...p, x: Math.max(.04, Math.min(.96, p.x + (p.teamId === 'A' ? shift * 1.5 : -shift * .5))) }))
    second.ball = { ...first.ball, x: template.pattern === 'block' ? .32 : .42, y: template.pattern === 'wide' ? .18 : .5 }
    third.ball = { ...first.ball, x: template.pattern === 'block' ? .45 : .76, y: template.pattern === 'wide' ? .78 : .5 }
    const runType = template.pattern === 'press' ? 'press' : template.pattern === 'block' ? 'defensiveMove' : 'run'
    second.drawings = [makeDrawing(runType, [{ x: .44, y: .5 }, { x: .62, y: template.pattern === 'wide' ? .18 : .38 }]), makeDrawing('pass', [first.ball, second.ball])]
    third.drawings = [makeDrawing('pass', [second.ball, third.ball]), makeDrawing(runType, [{ x: .62, y: .62 }, { x: .82, y: .5 }])]
    second.transition.ballPath = { delay: 450, duration: 950, easing: 'easeOut', curve: template.pattern === 'wide' ? .12 : 0, showPath: true }
  }
  plan.sequences[0].name = t(template.nameKey)
  plan.sequences[0].category = template.category
  plan.sequences[0].steps = [first, second, third]
  return plan
}
