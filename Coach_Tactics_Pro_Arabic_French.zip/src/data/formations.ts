import type { Formation, Point } from '@/types'

const p = (number: number, position: string, x: number, y: number) => ({ number, position, x, y })
const backFour = [p(2, 'RB', .22, .14), p(4, 'CB', .2, .38), p(5, 'CB', .2, .62), p(3, 'LB', .22, .86)]
const backThree = [p(4, 'RCB', .2, .25), p(5, 'CB', .18, .5), p(3, 'LCB', .2, .75)]
const backFive = [p(2, 'RWB', .3, .1), p(4, 'RCB', .18, .3), p(5, 'CB', .16, .5), p(6, 'LCB', .18, .7), p(3, 'LWB', .3, .9)]
const gk = p(1, 'GK', .065, .5)

export const formationPresets: Formation[] = [
  { id: '4-3-3', name: '4-3-3', custom: false, positions: [gk, ...backFour, p(6, 'DM', .39, .5), p(8, 'CM', .46, .3), p(10, 'CM', .46, .7), p(7, 'RW', .72, .17), p(9, 'ST', .74, .5), p(11, 'LW', .72, .83)] },
  { id: '4-4-2', name: '4-4-2', custom: false, positions: [gk, ...backFour, p(7, 'RM', .48, .14), p(6, 'CM', .42, .38), p(8, 'CM', .42, .62), p(11, 'LM', .48, .86), p(9, 'ST', .7, .39), p(10, 'ST', .7, .61)] },
  { id: '4-2-3-1', name: '4-2-3-1', custom: false, positions: [gk, ...backFour, p(6, 'DM', .38, .38), p(8, 'DM', .38, .62), p(7, 'RAM', .57, .18), p(10, 'AM', .56, .5), p(11, 'LAM', .57, .82), p(9, 'ST', .75, .5)] },
  { id: '4-1-4-1', name: '4-1-4-1', custom: false, positions: [gk, ...backFour, p(6, 'DM', .34, .5), p(7, 'RM', .52, .14), p(8, 'CM', .48, .38), p(10, 'CM', .48, .62), p(11, 'LM', .52, .86), p(9, 'ST', .74, .5)] },
  { id: '3-5-2', name: '3-5-2', custom: false, positions: [gk, ...backThree, p(2, 'RWB', .48, .1), p(6, 'CM', .42, .34), p(8, 'DM', .36, .5), p(10, 'CM', .42, .66), p(7, 'LWB', .48, .9), p(9, 'ST', .72, .39), p(11, 'ST', .72, .61)] },
  { id: '3-4-3', name: '3-4-3', custom: false, positions: [gk, ...backThree, p(2, 'RM', .47, .14), p(6, 'CM', .4, .39), p(8, 'CM', .4, .61), p(10, 'LM', .47, .86), p(7, 'RW', .72, .18), p(9, 'ST', .74, .5), p(11, 'LW', .72, .82)] },
  { id: '5-3-2', name: '5-3-2', custom: false, positions: [gk, ...backFive, p(8, 'CM', .45, .3), p(7, 'DM', .39, .5), p(10, 'CM', .45, .7), p(9, 'ST', .7, .39), p(11, 'ST', .7, .61)] },
  { id: '5-4-1', name: '5-4-1', custom: false, positions: [gk, ...backFive, p(7, 'RM', .5, .16), p(8, 'CM', .43, .39), p(10, 'CM', .43, .61), p(11, 'LM', .5, .84), p(9, 'ST', .72, .5)] },
]

export const getFormation = (id: string, custom: Formation[] = []) => [...formationPresets, ...custom].find(f => f.id === id) ?? formationPresets[0]
export const mirrorFormation = (points: Point[]) => points.map(point => ({ ...point, x: 1 - point.x }))
