import { useEffect, useState } from 'react'
import { Copy, Lock, LockOpen, Plus, RotateCcw, Save, Trash2, UserPlus, Users, X } from 'lucide-react'
import { activeStep, useAppStore } from '@/store/appStore'
import { formationPresets } from '@/data/formations'
import { useT } from '@/i18n'
import { Button, Field, IconButton, Modal, Toggle } from './Controls'

export function Inspector({ onClose }: { onClose?: () => void }) {
  const t = useT()
  const selectedDrawingId = useAppStore(state => state.selectedDrawingId)
  const [tab, setTab] = useState<'players' | 'drawing' | 'step'>('players')
  useEffect(() => { if (selectedDrawingId) setTab('drawing') }, [selectedDrawingId])
  return <aside className="inspector">
    <div className="inspector-tabs">
      {(['players', 'drawing', 'step'] as const).map(item => <button key={item} className={tab === item ? 'is-active' : ''} onClick={() => setTab(item)}>{t(`panel.${item}`)}</button>)}
      {onClose && <IconButton label={t('action.close')} onClick={onClose}><X size={17} /></IconButton>}
    </div>
    <div className="inspector-scroll">
      {tab === 'players' && <PlayersPanel />}
      {tab === 'drawing' && <DrawingPanel />}
      {tab === 'step' && <StepPanel />}
    </div>
  </aside>
}

function PlayersPanel() {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const selectedIds = useAppStore(state => state.selectedPlayerIds)
  const settings = useAppStore(state => state.settings)
  const customFormations = useAppStore(state => state.customFormations)
  const store = useAppStore()
  const step = activeStep(plan, stepIndex)
  const player = step.players.find(item => item.id === selectedIds[0])
  const [saveFormation, setSaveFormation] = useState(false)
  const [formationName, setFormationName] = useState('')
  const formations = [...formationPresets, ...customFormations]
  return <div className="form-stack">
    <div className="formation-block">
      <Field label={t('plan.formation')}><select value={plan.formation} onChange={event => store.applyFormation('A', event.target.value)}>{formations.map(formation => <option key={formation.id} value={formation.id}>{formation.name}</option>)}</select></Field>
      <div className="button-grid"><Button size="small" onClick={() => store.applyFormation('A', plan.formation)}><RotateCcw size={15} />{t('players.resetFormation')}</Button><Button size="small" onClick={() => setSaveFormation(true)}><Save size={15} />{t('players.saveFormation')}</Button></div>
    </div>
    <details className="plan-details"><summary>{t('plan.description')}</summary><div className="form-stack">
      <Field label={t('plan.description')}><textarea rows={3} value={plan.description} onChange={event => store.updateMetadata({ description: event.target.value })} /></Field>
      <Field label={t('plan.category')}><select value={plan.category} onChange={event => store.updateMetadata({ category: event.target.value as typeof plan.category })}>{['attacking', 'defensive', 'transitions', 'setPieces', 'custom'].map(category => <option key={category} value={category}>{t(`category.${category}`)}</option>)}</select></Field>
      <Field label={t('plan.opponent')}><input value={plan.opponentName} onChange={event => store.updateMetadata({ opponentName: event.target.value })} /></Field>
      <Field label={t('plan.match')}><input value={plan.matchLabel} onChange={event => store.updateMetadata({ matchLabel: event.target.value })} /></Field>
    </div></details>
    <div className="team-section">
      <div className="team-heading"><span className="team-dot" style={{ background: plan.teamA.color }} /><input aria-label={t('plan.teamName')} value={plan.teamA.name} onChange={event => store.updateMetadata({ teamA: { ...plan.teamA, name: event.target.value } })} /><input className="color-input" aria-label={t('drawing.color')} type="color" value={plan.teamA.color} onChange={event => store.updateMetadata({ teamA: { ...plan.teamA, color: event.target.value } })} /></div>
      <Button size="small" onClick={() => store.addPlayer('A')}><UserPlus size={15} />{t('players.addA')}</Button>
    </div>
    <div className="team-section">
      <div className="team-heading"><span className="team-dot" style={{ background: plan.teamB.color }} /><input aria-label={t('plan.opponent')} value={plan.teamB.name} onChange={event => store.updateMetadata({ teamB: { ...plan.teamB, name: event.target.value } })} /><input className="color-input" aria-label={t('drawing.color')} type="color" value={plan.teamB.color} onChange={event => store.updateMetadata({ teamB: { ...plan.teamB, color: event.target.value } })} /></div>
      <div className="button-grid"><Button size="small" onClick={() => store.addPlayer('B')}><Plus size={15} />{t('players.addB')}</Button><Button size="small" variant={plan.teamB.visible ? 'secondary' : 'ghost'} onClick={() => store.toggleTeam('B')}><Users size={15} />{plan.teamB.visible ? t('players.hideOpponent') : t('players.showOpponent')}</Button></div>
      {plan.teamB.visible && <Field label={`${t('plan.formation')} · ${plan.teamB.name}`}><select value={plan.teamB.formation} onChange={event => store.applyFormation('B', event.target.value)}>{formationPresets.map(formation => <option key={formation.id} value={formation.id}>{formation.name}</option>)}</select></Field>}
    </div>
    <div className="selection-summary"><span>{selectedIds.length} {t('players.selected')}</span><span>{step.players.length} / 22</span></div>
    {player ? <div className="player-editor">
      <div className="player-editor-title"><strong>#{player.number} · {player.position}</strong><IconButton label={player.locked ? t('players.unlock') : t('players.lock')} onClick={() => store.updatePlayer(player.id, { locked: !player.locked })}>{player.locked ? <Lock size={16} /> : <LockOpen size={16} />}</IconButton></div>
      <div className="field-row"><Field label={t('players.number')}><input type="number" min="1" max="99" value={player.number} onChange={event => store.updatePlayer(player.id, { number: Math.max(1, Math.min(99, Number(event.target.value))) })} /></Field><Field label={t('players.position')}><input value={player.position} maxLength={8} onChange={event => store.updatePlayer(player.id, { position: event.target.value.toUpperCase() })} /></Field></div>
      <Field label={t('players.name')}><input value={player.name} maxLength={24} onChange={event => store.updatePlayer(player.id, { name: event.target.value })} /></Field>
      <Toggle label={t('players.trail')} checked={player.trail} onChange={checked => store.updatePlayer(player.id, { trail: checked })} />
      <Toggle label={t('players.visible')} checked={player.visible} onChange={checked => store.updatePlayer(player.id, { visible: checked })} />
      <div className="button-grid"><Button size="small" onClick={() => store.duplicatePlayer(player.id)}><Copy size={15} />{t('players.duplicate')}</Button><Button size="small" variant="danger" onClick={() => { store.deletePlayer(player.id); store.selectPlayers([]) }}><Trash2 size={15} />{t('players.remove')}</Button></div>
    </div> : <p className="muted-copy">{t('players.noSelection')}</p>}
    <div className="marker-settings">
      <Field label={t('players.markerSize')}><input type="range" min="15" max="34" value={settings.markerSize} onChange={event => store.setSettings({ markerSize: Number(event.target.value) })} /></Field>
      <Field label={t('players.markerShape')}><select value={settings.markerShape} onChange={event => store.setSettings({ markerShape: event.target.value as 'circle' | 'shirt' })}><option value="circle">{t('players.circle')}</option><option value="shirt">{t('players.shirt')}</option></select></Field>
      <Toggle label={t('players.labels')} checked={settings.showLabels} onChange={checked => store.setSettings({ showLabels: checked })} />
    </div>
    {saveFormation && <Modal title={t('players.saveFormation')} onClose={() => setSaveFormation(false)}><form className="form-stack" onSubmit={async event => { event.preventDefault(); if (formationName.trim()) { await store.saveCustomFormation(formationName.trim()); setSaveFormation(false); setFormationName('') } }}><Field label={t('plan.formation')}><input autoFocus required value={formationName} onChange={event => setFormationName(event.target.value)} /></Field><Button variant="primary" type="submit">{t('action.save')}</Button></form></Modal>}
  </div>
}

function DrawingPanel() {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const id = useAppStore(state => state.selectedDrawingId)
  const store = useAppStore()
  const drawing = activeStep(plan, stepIndex).drawings.find(item => item.id === id)
  if (!drawing) return <p className="muted-copy">{t('drawing.none')}</p>
  const setCurvature = (curve: number) => {
    if (drawing.points.length < 2) return
    const start = drawing.points[0]; const end = drawing.points.at(-1)!
    const control = { x: (start.x + end.x) / 2 - (end.y - start.y) * curve, y: (start.y + end.y) / 2 + (end.x - start.x) * curve }
    store.updateDrawing(drawing.id, { points: drawing.points.length === 2 ? [start, control, end] : [start, control, end] })
  }
  return <div className="form-stack">
    <div className="selected-tool-name"><strong>{t(`tool.${drawing.type}`)}</strong><IconButton label={drawing.locked ? t('players.unlock') : t('drawing.locked')} onClick={() => store.updateDrawing(drawing.id, { locked: !drawing.locked })}>{drawing.locked ? <Lock size={16} /> : <LockOpen size={16} />}</IconButton></div>
    <div className="field-row"><Field label={t('drawing.color')}><input type="color" value={drawing.color} onChange={event => store.updateDrawing(drawing.id, { color: event.target.value })} /></Field><Field label={t('drawing.fill')}><input type="color" value={drawing.fill === 'none' ? '#fbbf24' : drawing.fill} onChange={event => store.updateDrawing(drawing.id, { fill: event.target.value })} /></Field></div>
    <Field label={t('drawing.thickness')}><input type="range" min="1" max="12" value={drawing.width} onChange={event => store.updateDrawing(drawing.id, { width: Number(event.target.value) })} /></Field>
    <Field label={t('drawing.opacity')}><input type="range" min="0.1" max="1" step="0.05" value={drawing.opacity} onChange={event => store.updateDrawing(drawing.id, { opacity: Number(event.target.value) })} /></Field>
    <Field label={t('drawing.fillOpacity')}><input type="range" min="0" max="1" step="0.05" value={drawing.fillOpacity} onChange={event => store.updateDrawing(drawing.id, { fillOpacity: Number(event.target.value) })} /></Field>
    {drawing.points.length >= 2 && !['circle', 'rectangle', 'zone', 'polygon', 'text', 'number'].includes(drawing.type) && <Field label={t('drawing.curvature')}><input type="range" min="-.8" max=".8" step=".02" defaultValue="0" onChange={event => setCurvature(Number(event.target.value))} /></Field>}
    <Field label={t('drawing.label')}><input value={drawing.label} onChange={event => store.updateDrawing(drawing.id, { label: event.target.value })} /></Field>
    <div className="button-grid"><Button size="small" onClick={() => store.duplicateDrawing(drawing.id)}><Copy size={15} />{t('action.duplicate')}</Button><Button size="small" variant="danger" onClick={() => store.deleteDrawing(drawing.id)}><Trash2 size={15} />{t('action.delete')}</Button></div>
  </div>
}

function StepPanel() {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const selectedPlayerIds = useAppStore(state => state.selectedPlayerIds)
  const store = useAppStore()
  const step = activeStep(plan, stepIndex)
  const selectedPath = selectedPlayerIds[0] ? step.transition.playerPaths[selectedPlayerIds[0]] : undefined
  return <div className="form-stack">
    <Field label={t('sequence.titleLabel')}><input value={step.title} onChange={event => store.updateStep({ title: event.target.value })} /></Field>
    <Field label={t('sequence.instructions')}><textarea rows={5} value={step.instructions} onChange={event => store.updateStep({ instructions: event.target.value })} /></Field>
    <Field label={t('sequence.transition')}><div className="range-with-value"><input type="range" min="0" max="8000" step="100" value={step.transition.duration} onChange={event => store.updateTransition({ duration: Number(event.target.value) })} /><span>{(step.transition.duration / 1000).toFixed(1)}s</span></div></Field>
    <Field label={t('sequence.easing')}><select value={step.transition.easing} onChange={event => store.updateTransition({ easing: event.target.value as typeof step.transition.easing })}><option value="easeInOut">{t('sequence.easeInOut')}</option><option value="easeOut">{t('sequence.easeOut')}</option><option value="linear">{t('sequence.linear')}</option></select></Field>
    <Toggle label={t('sequence.instant')} checked={step.transition.instant} onChange={checked => store.updateTransition({ instant: checked })} />
    <div className="ball-path-editor"><h3>{t('ball.title')}</h3>
      <Field label={t('ball.delay')}><div className="range-with-value"><input type="range" min="0" max="5000" step="100" value={step.transition.ballPath.delay} onChange={event => store.updateBallPath({ delay: Number(event.target.value) })} /><span>{step.transition.ballPath.delay}ms</span></div></Field>
      <Field label={t('ball.duration')}><div className="range-with-value"><input type="range" min="100" max="8000" step="100" value={step.transition.ballPath.duration} onChange={event => store.updateBallPath({ duration: Number(event.target.value) })} /><span>{step.transition.ballPath.duration}ms</span></div></Field>
      <Field label={t('ball.curve')}><input type="range" min="-.8" max=".8" step=".02" value={step.transition.ballPath.curve} onChange={event => store.updateBallPath({ curve: Number(event.target.value) })} /></Field>
    </div>
    {selectedPlayerIds[0] && <div className="ball-path-editor"><h3>{t('tool.run')} · {selectedPlayerIds.length} {t('players.selected')}</h3>
      <Field label={t('sequence.movementDelay')}><input type="range" min="0" max="5000" step="100" value={selectedPath?.delay ?? 0} onChange={event => store.updatePlayerPath(selectedPlayerIds[0], { delay: Number(event.target.value) })} /></Field>
      <Field label={t('sequence.movementDuration')}><input type="range" min="100" max="8000" step="100" value={selectedPath?.duration ?? step.transition.duration} onChange={event => store.updatePlayerPath(selectedPlayerIds[0], { duration: Number(event.target.value) })} /></Field>
      <Field label={t('drawing.curvature')}><input type="range" min="-.8" max=".8" step=".02" value={selectedPath?.curve ?? 0} onChange={event => store.updatePlayerPath(selectedPlayerIds[0], { curve: Number(event.target.value) })} /></Field>
    </div>}
    <div className="button-grid"><Button size="small" onClick={store.duplicateStep}><Copy size={15} />{t('sequence.duplicate')}</Button><Button size="small" onClick={store.resetStep}><RotateCcw size={15} />{t('sequence.reset')}</Button></div>
    <Button variant="danger" size="small" disabled={useAppStore.getState().plan.sequences.find(item => item.id === plan.activeSequenceId)?.steps.length === 1} onClick={store.deleteStep}><Trash2 size={15} />{t('sequence.delete')}</Button>
  </div>
}
