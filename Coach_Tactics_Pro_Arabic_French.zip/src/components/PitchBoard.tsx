import { useMemo, useRef, useState, type PointerEvent, type RefObject } from 'react'
import { Maximize, Minus, Plus, RotateCcw, Scan } from 'lucide-react'
import type { Point, TacticalDrawing, TacticalPlayer, TacticalStep } from '@/types'
import { activeSequence, activeStep, useAppStore } from '@/store/appStore'
import { interpolateStep, quadraticPoint } from '@/engine/animation'
import { fromBase, getViewBox, toBase } from '@/engine/coordinates'
import { drawingDefaults } from '@/data/factory'
import { uid } from '@/lib/utils'
import { useT } from '@/i18n'
import { IconButton } from './Controls'
import { PitchMarkings } from './PitchMarkings'
import { DrawingShape } from './DrawingShape'

type DragState =
  | { kind: 'players'; pointerId: number; last: Point; ids: string[] }
  | { kind: 'ball'; pointerId: number }
  | { kind: 'drawing'; pointerId: number; id: string; last: Point }
  | { kind: 'handle'; pointerId: number; id: string; index: number }
  | { kind: 'pan'; pointerId: number; x: number; y: number }
  | { kind: 'draw'; pointerId: number }
  | null

const curvedTypes = ['curvedArrow', 'dribble', 'overlap', 'underlap']

export function PitchBoard({ presentation = false, svgRef }: { presentation?: boolean; svgRef?: RefObject<SVGSVGElement | null> }) {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const settings = useAppStore(state => state.settings)
  const tool = useAppStore(state => state.tool)
  const selectedPlayerIds = useAppStore(state => state.selectedPlayerIds)
  const selectedDrawingId = useAppStore(state => state.selectedDrawingId)
  const playback = useAppStore(state => state.playback)
  const store = useAppStore
  const sequence = activeSequence(plan)
  const current = activeStep(plan, stepIndex)
  const next = sequence.steps[stepIndex + 1]
  const previous = sequence.steps[stepIndex - 1]
  const shown: TacticalStep = playback.progress > 0 && next ? interpolateStep(current, next, playback.progress) : current
  const localSvgRef = useRef<SVGSVGElement>(null)
  const actualSvgRef = svgRef ?? localSvgRef
  const coordinateGroup = useRef<SVGGElement>(null)
  const wrapperRef = useRef<HTMLDivElement>(null)
  const drag = useRef<DragState>(null)
  const [draft, setDraft] = useState<TacticalDrawing | null>(null)
  const [polygon, setPolygon] = useState<Point[]>([])
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })

  const pointFromEvent = (event: PointerEvent): Point => {
    const svg = actualSvgRef.current!
    const matrix = coordinateGroup.current!.getScreenCTM()!
    const point = svg.createSVGPoint(); point.x = event.clientX; point.y = event.clientY
    const base = point.matrixTransform(matrix.inverse())
    return fromBase(base, settings.attackDirection)
  }
  const capture = (event: PointerEvent) => {
    try { actualSvgRef.current?.setPointerCapture(event.pointerId) } catch { /* pointer may already be cancelled */ }
  }
  const resetGesture = () => { drag.current = null; setDraft(null) }

  const beginPlayers = (event: PointerEvent, player: TacticalPlayer) => {
    if (presentation || tool !== 'select') return
    event.stopPropagation(); capture(event)
    let ids = selectedPlayerIds
    if (event.shiftKey) {
      ids = ids.includes(player.id) ? ids.filter(id => id !== player.id) : [...ids, player.id]
      store.getState().selectPlayers(ids)
      return
    }
    if (!ids.includes(player.id)) ids = [player.id]
    store.getState().selectPlayers(ids)
    if (player.locked) return
    store.getState().checkpoint()
    drag.current = { kind: 'players', pointerId: event.pointerId, last: pointFromEvent(event), ids }
  }
  const beginBall = (event: PointerEvent) => {
    if (presentation || tool !== 'select') return
    event.stopPropagation(); capture(event); store.getState().selectPlayers([]); store.getState().checkpoint()
    drag.current = { kind: 'ball', pointerId: event.pointerId }
  }
  const beginDrawing = (event: PointerEvent, drawing: TacticalDrawing) => {
    if (presentation) return
    event.stopPropagation()
    if (tool === 'eraser') { store.getState().deleteDrawing(drawing.id); return }
    if (tool !== 'select') return
    capture(event); store.getState().selectDrawing(drawing.id)
    if (drawing.locked) return
    store.getState().checkpoint()
    drag.current = { kind: 'drawing', pointerId: event.pointerId, id: drawing.id, last: pointFromEvent(event) }
  }
  const beginHandle = (event: PointerEvent, drawing: TacticalDrawing, index: number) => {
    if (presentation || drawing.locked) return
    event.stopPropagation(); capture(event); store.getState().checkpoint()
    drag.current = { kind: 'handle', pointerId: event.pointerId, id: drawing.id, index }
  }

  const beginPitch = (event: PointerEvent) => {
    if (presentation) return
    const point = pointFromEvent(event)
    if (tool === 'select') { store.getState().selectPlayers([]); store.getState().selectDrawing(null); return }
    if (tool === 'pan') {
      capture(event); drag.current = { kind: 'pan', pointerId: event.pointerId, x: event.clientX, y: event.clientY }; return
    }
    if (tool === 'eraser') return
    capture(event)
    if (tool === 'polygon') {
      setPolygon(items => [...items, point]); return
    }
    if (tool === 'text' || tool === 'number') {
      const drawing = store.getState().addDrawing(tool, [point])
      store.getState().updateDrawing(drawing.id, { label: tool === 'number' ? String(current.drawings.filter(item => item.type === 'number').length + 1) : t('tool.text') }, false)
      return
    }
    const drawing: TacticalDrawing = {
      id: uid('draft'), type: tool, points: curvedTypes.includes(tool) ? [point, point, point] : [point, point],
      ...drawingDefaults(tool), opacity: 1, label: '', locked: false,
    }
    drag.current = { kind: 'draw', pointerId: event.pointerId }; setDraft(drawing)
  }

  const movePointer = (event: PointerEvent) => {
    const active = drag.current
    if (!active || active.pointerId !== event.pointerId) return
    const point = pointFromEvent(event)
    if (active.kind === 'players') {
      store.getState().movePlayers(active.ids, point.x - active.last.x, point.y - active.last.y)
      active.last = point
    } else if (active.kind === 'ball') {
      store.getState().updateBall(point, false)
    } else if (active.kind === 'drawing') {
      const drawing = current.drawings.find(item => item.id === active.id)
      if (drawing) store.getState().updateDrawing(active.id, { points: drawing.points.map(item => ({ x: Math.max(0, Math.min(1, item.x + point.x - active.last.x)), y: Math.max(0, Math.min(1, item.y + point.y - active.last.y)) })) }, false)
      active.last = point
    } else if (active.kind === 'handle') {
      const drawing = current.drawings.find(item => item.id === active.id)
      if (drawing) store.getState().updateDrawing(active.id, { points: drawing.points.map((item, index) => index === active.index ? point : item) }, false)
    } else if (active.kind === 'pan') {
      const rect = actualSvgRef.current!.getBoundingClientRect()
      setPan(value => ({ x: value.x + (event.clientX - active.x) * 1050 / rect.width, y: value.y + (event.clientY - active.y) * 680 / rect.height }))
      active.x = event.clientX; active.y = event.clientY
    } else if (active.kind === 'draw' && draft) {
      setDraft(value => {
        if (!value) return null
        if (value.type === 'freehand') return { ...value, points: [...value.points, point] }
        if (curvedTypes.includes(value.type)) {
          const start = value.points[0]
          return { ...value, points: [start, { x: (start.x + point.x) / 2 - (point.y - start.y) * .18, y: (start.y + point.y) / 2 + (point.x - start.x) * .18 }, point] }
        }
        return { ...value, points: [value.points[0], point] }
      })
    }
  }

  const endPointer = (event: PointerEvent) => {
    const active = drag.current
    if (!active || active.pointerId !== event.pointerId) return
    if (active.kind === 'draw' && draft) {
      const valid = draft.type === 'freehand' ? draft.points.length > 2 : draft.points.some(point => Math.hypot(point.x - draft.points[0].x, point.y - draft.points[0].y) > .005)
      if (valid) store.getState().addDrawing(draft.type, draft.points)
    }
    resetGesture()
    try { actualSvgRef.current?.releasePointerCapture(event.pointerId) } catch { /* already released */ }
  }

  const finishPolygon = () => {
    if (polygon.length >= 3) store.getState().addDrawing('polygon', polygon)
    setPolygon([])
  }

  const resetView = () => { setZoom(1); setPan({ x: 0, y: 0 }) }
  const requestFullscreen = async () => {
    try { await wrapperRef.current?.requestFullscreen() } catch { /* browser fallback keeps the board usable */ }
  }

  const trails = useMemo(() => {
    const from = playback.progress > 0 ? current : previous
    const to = playback.progress > 0 ? next : current
    if (!from || !to || !settings.showTrails) return []
    return to.players.flatMap(target => {
      const source = from.players.find(player => player.id === target.id)
      if (!source || !target.trail || (source.x === target.x && source.y === target.y)) return []
      const curve = to.transition.playerPaths[target.id]?.curve ?? 0
      const points = Array.from({ length: 13 }, (_, index) => toBase(quadraticPoint(source, target, index / 12, curve), settings.attackDirection))
      return [{ id: target.id, color: target.teamId === 'A' ? plan.teamA.color : plan.teamB.color, path: points.map((point, index) => `${index ? 'L' : 'M'}${point.x},${point.y}`).join(' ') }]
    })
  }, [current, previous, next, playback.progress, settings.showTrails, settings.attackDirection, plan.teamA.color, plan.teamB.color])

  const ballTrail = useMemo(() => {
    const from = playback.progress > 0 ? current : previous
    const to = playback.progress > 0 ? next : current
    if (!from || !to || !settings.showTrails || !to.ball.trail) return ''
    return Array.from({ length: 13 }, (_, index) => toBase(quadraticPoint(from.ball, to.ball, index / 12, to.transition.ballPath.curve), settings.attackDirection)).map((point, index) => `${index ? 'L' : 'M'}${point.x},${point.y}`).join(' ')
  }, [current, previous, next, playback.progress, settings.showTrails, settings.attackDirection])

  const direction = settings.attackDirection
  const markerSize = settings.markerSize + (presentation ? 4 : 0)
  const cursor = presentation ? 'default' : tool === 'select' ? 'default' : tool === 'pan' ? 'grab' : tool === 'eraser' ? 'not-allowed' : 'crosshair'

  return <div className={`pitch-shell ${presentation ? 'pitch-presentation' : ''}`} ref={wrapperRef}>
    <svg ref={actualSvgRef} className="tactical-pitch" viewBox={getViewBox(settings.pitchView, settings.orientation, direction)} preserveAspectRatio="xMidYMid meet" style={{ touchAction: 'none', cursor }} role="img" aria-label={t('nav.workspace')}
      onPointerDown={beginPitch} onPointerMove={movePointer} onPointerUp={endPointer} onPointerCancel={resetGesture} onDoubleClick={finishPolygon}>
      <g transform={settings.orientation === 'portrait' ? 'translate(0 1050) rotate(-90)' : undefined}>
        <g ref={coordinateGroup} transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
          <PitchMarkings grid={settings.showGrid} />
          {settings.showTeamLabels && <g data-team-labels fill="var(--pitch-line)" fontSize="13" fontWeight="700" letterSpacing="2"><text x="42" y="28">{plan.teamA.name.toUpperCase()}</text><text x="1008" y="28" textAnchor="end">{plan.teamB.visible ? plan.teamB.name.toUpperCase() : t('pitch.away')}</text></g>}
          <g data-layer="trails" fill="none" strokeWidth="3" strokeDasharray="4 8" opacity=".55" vectorEffect="non-scaling-stroke">
            {trails.map(trail => <path key={trail.id} d={trail.path} stroke={trail.color} vectorEffect="non-scaling-stroke" />)}
            {ballTrail && <path d={ballTrail} stroke="var(--ball-trail)" vectorEffect="non-scaling-stroke" />}
          </g>
          <g data-layer="drawings">
            {current.drawings.filter(drawing => settings.showPaths || !['pass', 'ballPath'].includes(drawing.type)).map(drawing => <DrawingShape key={drawing.id} drawing={drawing} direction={direction} selected={!presentation && drawing.id === selectedDrawingId} onPointerDown={beginDrawing} onHandlePointerDown={beginHandle} />)}
            {draft && <DrawingShape drawing={draft} direction={direction} selected={false} onPointerDown={() => undefined} onHandlePointerDown={() => undefined} />}
            {polygon.length > 0 && <polyline points={polygon.map(point => { const p = toBase(point, direction); return `${p.x},${p.y}` }).join(' ')} fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth="3" />}
          </g>
          {(['A', 'B'] as const).map(teamId => <g key={teamId} data-layer={`team${teamId}`}>
            {(teamId === 'A' ? plan.teamA.visible : plan.teamB.visible) && shown.players.filter(player => player.teamId === teamId && player.visible).map(player => {
              const point = toBase(player, direction)
              const team = teamId === 'A' ? plan.teamA : plan.teamB
              const selected = !presentation && selectedPlayerIds.includes(player.id)
              return <g key={player.id} data-player-id={player.id} className={`player-marker ${player.locked ? 'is-locked' : ''}`} transform={`translate(${point.x} ${point.y})`} onPointerDown={event => beginPlayers(event, player)}>
                <circle r={markerSize + 9} fill="transparent" />
                {settings.markerShape === 'shirt' ? <path d={`M${-markerSize * .65} ${-markerSize * .8}L${-markerSize * 1.15} ${-markerSize * .3}L${-markerSize * .78} ${markerSize * .12}V${markerSize}H${markerSize * .78}V${markerSize * .12}L${markerSize * 1.15} ${-markerSize * .3}L${markerSize * .65} ${-markerSize * .8}Q0 ${-markerSize * .35} ${-markerSize * .65} ${-markerSize * .8}Z`} fill={team.color} stroke={selected ? 'var(--accent)' : 'var(--marker-ring)'} strokeWidth={selected ? 4 : 2.2} /> : <circle r={markerSize} fill={team.color} stroke={selected ? 'var(--accent)' : 'var(--marker-ring)'} strokeWidth={selected ? 4 : 2.2} />}
                <text textAnchor="middle" y="6" fill={team.textColor} fontSize={markerSize * .85} fontWeight="850" pointerEvents="none">{player.number}</text>
                {settings.showLabels && (player.name || player.position) && <text textAnchor="middle" y={markerSize + 17} fill="var(--pitch-line)" fontSize="12" fontWeight="700" paintOrder="stroke" stroke="var(--pitch-text-bg)" strokeWidth="4" pointerEvents="none">{player.name || player.position}</text>}
                {player.locked && !presentation && <path d="M-4-21h8v7h-8zM-2-21v-3a2 2 0 014 0v3" fill="var(--surface)" stroke="var(--text)" strokeWidth="1.5" />}
              </g>
            })}
          </g>)}
          {shown.ball.visible && <g data-layer="ball" transform={`translate(${toBase(shown.ball, direction).x} ${toBase(shown.ball, direction).y})`} className="ball-marker" onPointerDown={beginBall}>
            <circle r="20" fill="transparent" /><circle r="11" fill="var(--ball)" stroke="var(--ball-ring)" strokeWidth="2" /><path d="M0-5L5-1L3 5H-3L-5-1Z" fill="var(--ball-ring)" /><path d="M0-5V-10M5-1L10-3M3 5L6 9M-3 5L-6 9M-5-1L-10-3" stroke="var(--ball-ring)" strokeWidth="1.5" />
          </g>}
          {settings.showLegend && <g data-legend="true" transform="translate(272 659)" fontSize="11" fontWeight="650" fill="var(--legend-text)">
            {[
              ['legend.pass', 'var(--legend-pass)', '10 7'], ['legend.playerRun', 'var(--accent)', ''], ['legend.opponent', 'var(--legend-opponent)', ''], ['legend.pressing', 'var(--legend-press)', '4 5'],
            ].map(([label, color, dash], index) => <g key={label} transform={`translate(${[0, 72, 192, 382][index]} 0)`}><path d="M0-4H25" stroke={color} strokeWidth="3" strokeDasharray={dash} /><text x="31" y="0">{t(label)}</text></g>)}
          </g>}
        </g>
      </g>
    </svg>
    {!presentation && <div className="pitch-view-controls">
      <IconButton label={t('action.zoomOut')} onClick={() => setZoom(value => Math.max(.65, value - .15))}><Minus size={17} /></IconButton>
      <span className="zoom-value">{Math.round(zoom * 100)}%</span>
      <IconButton label={t('action.zoomIn')} onClick={() => setZoom(value => Math.min(2.5, value + .15))}><Plus size={17} /></IconButton>
      <IconButton label={t('action.fit')} onClick={resetView}><Scan size={17} /></IconButton>
      <IconButton label={t('action.resetView')} onClick={resetView}><RotateCcw size={16} /></IconButton>
      <IconButton label={t('action.fullscreen')} onClick={requestFullscreen}><Maximize size={17} /></IconButton>
    </div>}
    {polygon.length > 0 && <button className="polygon-hint" onClick={finishPolygon}>{t('drawing.finishPolygon')}</button>}
  </div>
}
