import { memo } from 'react'

export const PitchMarkings = memo(function PitchMarkings({ grid }: { grid: boolean }) {
  return <g data-layer="pitch">
    <rect x="0" y="0" width="1050" height="680" rx="22" fill="var(--pitch-outer)" />
    <rect x="25" y="40" width="1000" height="600" rx="3" fill="var(--pitch-green)" />
    {Array.from({ length: 10 }, (_, index) => <rect key={index} x={25 + index * 100} y="40" width="100" height="600" fill={index % 2 ? 'var(--pitch-stripe)' : 'transparent'} />)}
    <g fill="none" stroke="var(--pitch-line)" strokeWidth="2.4" vectorEffect="non-scaling-stroke">
      <rect x="25" y="40" width="1000" height="600" rx="2" />
      <path d="M525 40V640" />
      <circle cx="525" cy="340" r="91.5" />
      <path d="M25 175H190V505H25 M1025 175H860V505H1025" />
      <path d="M25 257.5H80V422.5H25 M1025 257.5H970V422.5H1025" />
      <path d="M190 256C235 275 235 405 190 424 M860 256C815 275 815 405 860 424" />
      <path d="M25 55A15 15 0 0 0 40 40 M1010 40A15 15 0 0 0 1025 55 M25 625A15 15 0 0 1 40 640 M1010 640A15 15 0 0 1 1025 625" />
      <path d="M17 295H25V385H17 M1033 295H1025V385H1033" strokeWidth="5" />
    </g>
    <g fill="var(--pitch-line)">
      <circle cx="525" cy="340" r="3.5" /><circle cx="135" cy="340" r="3.5" /><circle cx="915" cy="340" r="3.5" />
    </g>
    {grid && <g stroke="var(--pitch-grid)" strokeWidth="1" strokeDasharray="4 8" fill="var(--pitch-line)" fontSize="10" fontFamily="monospace">
      {Array.from({ length: 11 }, (_, index) => <g key={`x${index}`}><path d={`M${25 + index * 100} 40V640`} /><text x={30 + index * 100} y="58">{index * 10}</text></g>)}
      {Array.from({ length: 7 }, (_, index) => <g key={`y${index}`}><path d={`M25 ${40 + index * 100}H1025`} /><text x="32" y={35 + index * 100}>{index * 10}</text></g>)}
    </g>}
  </g>
})
