import { ArrowRight, Spline, ArrowUpRight, Waypoints, PersonStanding, CircleDot, Shield, Crosshair, RefreshCw, Undo2, PenLine, Circle, Square, Hexagon, Shapes, Minus, Octagon, Type, Hash, Eraser, MousePointer2, Hand, Dribbble } from 'lucide-react'
import type { Tool } from '@/types'
import { useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { IconButton } from './Controls'

const groups: Array<Array<{ tool: Tool; icon: typeof ArrowRight }>> = [
  [{ tool: 'select', icon: MousePointer2 }, { tool: 'pan', icon: Hand }],
  [{ tool: 'straightArrow', icon: ArrowRight }, { tool: 'curvedArrow', icon: Spline }, { tool: 'dashedArrow', icon: ArrowUpRight }, { tool: 'pass', icon: Waypoints }, { tool: 'run', icon: PersonStanding }, { tool: 'ballPath', icon: CircleDot }, { tool: 'dribble', icon: Dribbble }],
  [{ tool: 'defensiveMove', icon: Shield }, { tool: 'press', icon: Crosshair }, { tool: 'overlap', icon: RefreshCw }, { tool: 'underlap', icon: Undo2 }],
  [{ tool: 'freehand', icon: PenLine }, { tool: 'circle', icon: Circle }, { tool: 'rectangle', icon: Square }, { tool: 'polygon', icon: Hexagon }, { tool: 'zone', icon: Shapes }, { tool: 'defensiveLine', icon: Minus }, { tool: 'offsideLine', icon: Octagon }, { tool: 'text', icon: Type }, { tool: 'number', icon: Hash }, { tool: 'eraser', icon: Eraser }],
]

export function DrawingToolbar() {
  const t = useT()
  const tool = useAppStore(state => state.tool)
  const setTool = useAppStore(state => state.setTool)
  return <nav className="drawing-toolbar" aria-label={t('panel.drawing')}>
    {groups.map((group, index) => <div className="tool-group" key={index}>{group.map(({ tool: item, icon: Icon }) => <IconButton key={item} label={t(`tool.${item}`)} active={tool === item} onClick={() => setTool(item)}><Icon size={18} strokeWidth={tool === item ? 2.4 : 1.8} /></IconButton>)}</div>)}
  </nav>
}
