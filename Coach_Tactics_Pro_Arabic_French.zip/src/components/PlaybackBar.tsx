import { Pause, Play, RotateCcw, SkipBack, SkipForward } from 'lucide-react'
import { activeSequence, useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { IconButton } from './Controls'

export function PlaybackBar({ presentation = false }: { presentation?: boolean }) {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const playback = useAppStore(state => state.playback)
  const setPlayback = useAppStore(state => state.setPlayback)
  const setStepIndex = useAppStore(state => state.setStepIndex)
  const sequence = activeSequence(plan)
  const hasNext = stepIndex < sequence.steps.length - 1
  const play = () => {
    if (playback.playing) { setPlayback({ playing: false }); return }
    if (!hasNext) { setStepIndex(0); setPlayback({ playing: sequence.steps.length > 1, progress: 0 }); return }
    setPlayback({ playing: true })
  }
  const restart = () => { setStepIndex(0); setPlayback({ progress: 0, playing: sequence.steps.length > 1 }) }
  return <div className={`playback-bar ${presentation ? 'playback-present' : ''}`}>
    <div className="playback-buttons">
      <IconButton label={t('playback.restart')} onClick={restart}><RotateCcw size={18} /></IconButton>
      <IconButton label={t('playback.previous')} disabled={stepIndex === 0} onClick={() => setStepIndex(stepIndex - 1)}><SkipBack size={19} /></IconButton>
      <button className="play-button" onClick={play} aria-label={playback.playing ? t('playback.pause') : t('playback.play')}>{playback.playing ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" />}<span>{playback.playing ? t('playback.pause') : t('playback.play')}</span></button>
      <IconButton label={t('playback.next')} disabled={!hasNext} onClick={() => setStepIndex(stepIndex + 1)}><SkipForward size={19} /></IconButton>
    </div>
    <div className="scrub-wrap">
      <div className="scrub-label"><span>{t('sequence.step')} {stepIndex + 1} / {sequence.steps.length}</span><span>{Math.round(playback.progress * 100)}%</span></div>
      <input aria-label={t('playback.scrub')} type="range" min="0" max="1" step="0.001" value={playback.progress} disabled={!hasNext} onChange={event => setPlayback({ progress: Number(event.target.value), playing: false })} />
    </div>
    <label className="speed-control"><span>{t('playback.speed')}</span><select value={playback.speed} onChange={event => setPlayback({ speed: Number(event.target.value) })}>{[.5, .75, 1, 1.5, 2].map(speed => <option key={speed} value={speed}>{speed}×</option>)}</select></label>
    {!presentation && <label className="continuous-control" title={t('playback.continuous')}><input type="checkbox" checked={playback.continuous} onChange={event => setPlayback({ continuous: event.target.checked })} /><span>{t('playback.continuous')}</span></label>}
  </div>
}
