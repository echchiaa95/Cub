import { useState } from 'react'
import { Copy, GripVertical, Plus, ArrowLeft, ArrowRight, ListPlus } from 'lucide-react'
import { activeSequence, useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { Button, IconButton, Modal } from './Controls'

export function SequenceTimeline() {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const store = useAppStore()
  const sequence = activeSequence(plan)
  const [addOpen, setAddOpen] = useState(false)
  const [dragIndex, setDragIndex] = useState<number | null>(null)
  return <section className="timeline-section">
    <header className="timeline-header">
      <div><span className="section-kicker">{t('sequence.timeline')}</span><span className="sequence-detail">{t('sequence.independent')}</span></div>
      <div className="timeline-actions">
        <select aria-label={t('sequence.title')} value={plan.activeSequenceId} onChange={event => store.setActiveSequence(event.target.value)}>{plan.sequences.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
        <IconButton label={t('sequence.new')} onClick={() => store.newSequence(`${t('sequence.title')} ${plan.sequences.length + 1}`)}><ListPlus size={17} /></IconButton>
        <IconButton label={t('sequence.duplicateSequence')} onClick={store.duplicateSequence}><Copy size={16} /></IconButton>
        <Button variant="primary" size="small" onClick={() => setAddOpen(true)}><Plus size={16} />{t('sequence.add')}</Button>
      </div>
    </header>
    <div className="timeline-scroll" aria-label={t('sequence.reorder')}>
      {sequence.steps.map((step, index) => <article key={step.id} className={`step-card ${index === stepIndex ? 'is-current' : ''}`} draggable onDragStart={() => setDragIndex(index)} onDragOver={event => event.preventDefault()} onDrop={() => { if (dragIndex !== null) { store.reorderSteps(dragIndex, index); store.setStepIndex(index) } setDragIndex(null) }}>
        <button className="step-main" onClick={() => store.setStepIndex(index)}>
          <span className="step-number">{String(index + 1).padStart(2, '0')}</span>
          <span className="step-copy"><strong>{step.title}</strong><small>{step.players.length} · {(step.transition.duration / 1000).toFixed(1)}s</small></span>
        </button>
        <div className="step-card-actions">
          <GripVertical size={14} className="drag-grip" />
          <IconButton label={t('playback.previous')} disabled={index === 0} onClick={() => { store.reorderSteps(index, index - 1); store.setStepIndex(index - 1) }}><ArrowLeft size={13} /></IconButton>
          <IconButton label={t('playback.next')} disabled={index === sequence.steps.length - 1} onClick={() => { store.reorderSteps(index, index + 1); store.setStepIndex(index + 1) }}><ArrowRight size={13} /></IconButton>
        </div>
      </article>)}
      <button className="timeline-add-tile" onClick={() => setAddOpen(true)}><Plus size={18} /><span>{t('sequence.add')}</span></button>
    </div>
    {addOpen && <Modal title={t('sequence.add')} onClose={() => setAddOpen(false)}>
      <div className="choice-list">
        <button onClick={() => { store.addStep('copy'); setAddOpen(false) }}><Copy size={22} /><span><strong>{t('sequence.addCopy')}</strong><small>{t('sequence.independent')}</small></span></button>
        <button onClick={() => { store.addStep('blank'); setAddOpen(false) }}><Plus size={22} /><span><strong>{t('sequence.addBlank')}</strong><small>{t('steps.blank')}</small></span></button>
      </div>
    </Modal>}
  </section>
}
