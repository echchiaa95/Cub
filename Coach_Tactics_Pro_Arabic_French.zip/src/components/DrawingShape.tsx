import type { PointerEvent } from 'react'
import type { AttackDirection, Point, TacticalDrawing } from '@/types'
import { svgPathFromBase, toBase } from '@/engine/coordinates'

const curvedTypes = ['curvedArrow', 'dribble', 'overlap', 'underlap']
export function drawingBasePoints(drawing: TacticalDrawing, direction: AttackDirection): Point[] {
  const points = drawing.points.map(point => toBase(point, direction))
  if (curvedTypes.includes(drawing.type) && points.length === 2) {
    const [from, to] = points
    points.splice(1, 0, { x: (from.x + to.x) / 2 - (to.y - from.y) * .18, y: (from.y + to.y) / 2 + (to.x - from.x) * .18 })
  }
  return points
}

export function DrawingShape({ drawing, direction, selected, onPointerDown, onHandlePointerDown }: {
  drawing: TacticalDrawing
  direction: AttackDirection
  selected: boolean
  onPointerDown: (event: PointerEvent, drawing: TacticalDrawing) => void
  onHandlePointerDown: (event: PointerEvent, drawing: TacticalDrawing, index: number) => void
}) {
  const points = drawingBasePoints(drawing, direction)
  const start = points[0]
  const end = points.at(-1) ?? start
  const id = `arrow-${drawing.id}`
  const common = {
    stroke: drawing.color, strokeWidth: drawing.width, strokeDasharray: drawing.dash || undefined,
    opacity: drawing.opacity, fill: 'none', vectorEffect: 'non-scaling-stroke' as const,
    markerEnd: drawing.arrow ? `url(#${id})` : undefined,
  }
  let shape: React.ReactNode
  if (['circle'].includes(drawing.type)) {
    shape = <ellipse cx={(start.x + end.x) / 2} cy={(start.y + end.y) / 2} rx={Math.abs(end.x - start.x) / 2} ry={Math.abs(end.y - start.y) / 2} {...common} fill={drawing.fill} fillOpacity={drawing.fillOpacity} />
  } else if (['rectangle', 'zone'].includes(drawing.type)) {
    shape = <rect x={Math.min(start.x, end.x)} y={Math.min(start.y, end.y)} width={Math.abs(end.x - start.x)} height={Math.abs(end.y - start.y)} {...common} fill={drawing.fill} fillOpacity={drawing.fillOpacity} />
  } else if (drawing.type === 'polygon') {
    shape = <polygon points={points.map(point => `${point.x},${point.y}`).join(' ')} {...common} fill={drawing.fill} fillOpacity={drawing.fillOpacity} />
  } else if (drawing.type === 'text') {
    shape = <text x={start.x} y={start.y} fill={drawing.color} opacity={drawing.opacity} fontSize={drawing.width * 5 + 10} fontWeight="650" paintOrder="stroke" stroke="var(--pitch-text-bg)" strokeWidth="4" strokeLinejoin="round">{drawing.label || 'Text'}</text>
  } else if (drawing.type === 'number') {
    shape = <g opacity={drawing.opacity}><circle cx={start.x} cy={start.y} r={drawing.width * 3 + 8} fill={drawing.color} stroke="var(--marker-ring)" strokeWidth="2" /><text x={start.x} y={start.y + 5} textAnchor="middle" fill="var(--annotation-text)" fontSize="16" fontWeight="800">{drawing.label || '1'}</text></g>
  } else {
    const path = svgPathFromBase(points, curvedTypes.includes(drawing.type))
    shape = <><path d={path} {...common} /><path d={path} stroke="transparent" strokeWidth={Math.max(18, drawing.width + 12)} fill="none" vectorEffect="non-scaling-stroke" /></>
  }
  return <g data-drawing-id={drawing.id} className={drawing.locked ? 'drawing-locked' : 'drawing-selectable'} onPointerDown={event => onPointerDown(event, drawing)}>
    {drawing.arrow && <defs><marker id={id} markerWidth="14" markerHeight="14" refX="11" refY="6" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0L12 6L0 12Z" fill={drawing.color} opacity={drawing.opacity} /></marker></defs>}
    {shape}
    {drawing.label && !['text', 'number'].includes(drawing.type) && <text x={(start.x + end.x) / 2} y={(start.y + end.y) / 2 - 10} fill={drawing.color} fontSize="13" textAnchor="middle" paintOrder="stroke" stroke="var(--pitch-text-bg)" strokeWidth="4">{drawing.label}</text>}
    {selected && <g data-selection-overlay="true">
      <path d={svgPathFromBase(points, curvedTypes.includes(drawing.type))} fill="none" stroke="var(--accent)" strokeWidth="2" strokeDasharray="4 5" vectorEffect="non-scaling-stroke" />
      {points.map((point, index) => <circle key={index} cx={point.x} cy={point.y} r="8" fill="var(--surface)" stroke="var(--accent)" strokeWidth="3" className="drawing-handle" onPointerDown={event => onHandlePointerDown(event, drawing, index)} />)}
    </g>}
  </g>
}
