import { useRef, useState } from 'react'
import { FileImage, FileJson, FileText, Upload } from 'lucide-react'
import { toast } from 'sonner'
import { activeSequence, useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { exportPdf, exportPlanJson, exportPng, type PngOptions } from '@/services/exporters'
import { importPlanFile } from '@/services/transfer'
import { Button, Modal, Toggle } from './Controls'

export function ExportDialog({ onClose }: { onClose: () => void }) {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const settings = useAppStore(state => state.settings)
  const setPlan = useAppStore(state => state.setPlan)
  const [busy, setBusy] = useState<string | null>(null)
  const [options, setOptions] = useState<PngOptions>({ labels: settings.showLabels, teams: settings.showTeamLabels, legend: settings.showLegend, trails: settings.showTrails, selection: false, interface: false })
  const fileRef = useRef<HTMLInputElement>(null)
  const run = async (name: string, task: () => Promise<void> | void) => {
    setBusy(name)
    try { await task(); toast.success(t('export.success')) } catch { toast.error(t('export.failed')) } finally { setBusy(null) }
  }
  const png = () => run('png', async () => {
    const svg = document.querySelector<SVGSVGElement>('.tactical-pitch')
    if (!svg) throw new Error('Board unavailable')
    await exportPng(svg, plan, options)
  })
  return <Modal title={t('action.export')} onClose={onClose}>
    <div className="export-grid">
      <button disabled={!!busy} onClick={png}><FileImage size={26} /><strong>{t('export.png')}</strong><span>PNG · 1800px</span></button>
      <button disabled={!!busy} onClick={() => run('pdf', () => exportPdf(plan, activeSequence(plan).steps, settings))}><FileText size={26} /><strong>{t('export.pdf')}</strong><span>{activeSequence(plan).steps.length} {t('plan.steps')}</span></button>
      <button disabled={!!busy} onClick={() => run('json', () => exportPlanJson(plan))}><FileJson size={26} /><strong>{t('export.json')}</strong><span>JSON · v1</span></button>
      <button disabled={!!busy} onClick={() => fileRef.current?.click()}><Upload size={26} /><strong>{t('export.importJson')}</strong><span>{t('action.import')}</span></button>
    </div>
    <div className="export-options"><h3>{t('settings.exportOptions')}</h3>
      <Toggle label={t('export.includeLabels')} checked={options.labels} onChange={checked => setOptions({ ...options, labels: checked })} />
      <Toggle label={t('export.includeTeams')} checked={options.teams} onChange={checked => setOptions({ ...options, teams: checked })} />
      <Toggle label={t('export.includeLegend')} checked={options.legend} onChange={checked => setOptions({ ...options, legend: checked })} />
      <Toggle label={t('export.includeTrails')} checked={options.trails} onChange={checked => setOptions({ ...options, trails: checked })} />
      <Toggle label={t('export.includeSelection')} checked={options.selection} onChange={checked => setOptions({ ...options, selection: checked })} />
      <Toggle label={t('export.includeInterface')} checked={options.interface} onChange={checked => setOptions({ ...options, interface: checked })} />
    </div>
    <input ref={fileRef} hidden type="file" accept="application/json,.json" onChange={async event => {
      const file = event.target.files?.[0]; if (!file) return
      try { const imported = await importPlanFile(file); setPlan(imported); toast.success(t('export.importSuccess')); onClose() } catch { toast.error(t('messages.invalidFile')) }
      event.target.value = ''
    }} />
    {busy && <p className="busy-note">{t('status.saving')}</p>}
    <Button variant="ghost" onClick={onClose}>{t('action.close')}</Button>
  </Modal>
}
