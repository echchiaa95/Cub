import { useEffect, useState } from 'react'
import { NavLink, useNavigate } from 'react-router'
import { CloudOff, Download, FolderOpen, Globe2, LayoutTemplate, Library, Plus, Redo2, Save, Settings, Shield, Undo2, Wifi } from 'lucide-react'
import { useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { Button, IconButton } from './Controls'
import { ExportDialog } from './ExportDialog'

export function Header() {
  const t = useT()
  const navigate = useNavigate()
  const saveStatus = useAppStore(state => state.saveStatus)
  const language = useAppStore(state => state.settings.language)
  const store = useAppStore()
  const [exportOpen, setExportOpen] = useState(false)
  const [online, setOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine)
  useEffect(() => {
    const update = () => setOnline(navigator.onLine)
    window.addEventListener('online', update); window.addEventListener('offline', update)
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update) }
  }, [])
  const statusKey = saveStatus === 'saved' ? 'status.saved' : saveStatus === 'saving' ? 'status.saving' : saveStatus === 'failed' ? 'status.failed' : saveStatus === 'unavailable' ? 'status.unavailable' : 'status.localOnly'
  return <>
    <header className="app-header">
      <NavLink to="/" className="brand" aria-label={t('app.name')}><span className="brand-mark"><Shield size={20} /><span>CT</span></span><span className="brand-copy"><strong>COACH <b>TACTICS</b> PRO</strong><small>{t('app.tagline')}</small></span></NavLink>
      <nav className="main-nav" aria-label={t('app.name')}>
        <NavLink to="/" end><Shield size={16} /><span>{t('nav.workspace')}</span></NavLink>
        <NavLink to="/library"><Library size={16} /><span>{t('nav.library')}</span></NavLink>
        <NavLink to="/templates"><LayoutTemplate size={16} /><span>{t('nav.templates')}</span></NavLink>
        <NavLink to="/set-pieces"><FolderOpen size={16} /><span>{t('nav.setPieces')}</span></NavLink>
      </nav>
      <div className="header-actions">
        <label className="header-language" title={t('settings.language')}>
          <Globe2 size={15} aria-hidden="true" />
          <select aria-label={t('settings.language')} value={language} onChange={event => store.setSettings({ language: event.target.value as typeof language })}>
            <option value="en">EN</option>
            <option value="fr">FR</option>
            <option value="ar">عربي</option>
          </select>
        </label>
        <span className={`save-status status-${saveStatus}`}><span />{t(statusKey)}</span>
        <span className="network-status" title={online ? t('status.online') : t('status.offline')}>{online ? <Wifi size={15} /> : <CloudOff size={15} />}</span>
        <IconButton label={t('action.undo')} disabled={!store.past.length} onClick={store.undo}><Undo2 size={17} /></IconButton>
        <IconButton label={t('action.redo')} disabled={!store.future.length} onClick={store.redo}><Redo2 size={17} /></IconButton>
        <IconButton label={t('action.new')} onClick={() => { store.newPlan(t('library.new')); navigate('/') }}><Plus size={18} /></IconButton>
        <IconButton label={t('action.save')} onClick={() => void store.saveNow()}><Save size={17} /></IconButton>
        <Button variant="primary" size="small" onClick={() => setExportOpen(true)}><Download size={16} /><span>{t('action.export')}</span></Button>
        <NavLink to="/settings" className="settings-link" aria-label={t('nav.settings')}><Settings size={18} /></NavLink>
      </div>
    </header>
    {exportOpen && <ExportDialog onClose={() => setExportOpen(false)} />}
  </>
}
