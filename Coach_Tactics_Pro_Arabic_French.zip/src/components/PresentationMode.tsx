import { useEffect, useRef } from 'react'
import { X, Route, List, Footprints } from 'lucide-react'
import { activeStep, useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { IconButton } from './Controls'
import { PitchBoard } from './PitchBoard'
import { PlaybackBar } from './PlaybackBar'

export function PresentationMode() {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const settings = useAppStore(state => state.settings)
  const setPlayback = useAppStore(state => state.setPlayback)
  const setStepIndex = useAppStore(state => state.setStepIndex)
  const setSettings = useAppStore(state => state.setSettings)
  const playing = useAppStore(state => state.playback.playing)
  const overlay = useRef<HTMLDivElement>(null)
  const step = activeStep(plan, stepIndex)
  const exit = () => setPlayback({ presentation: false, playing: false, progress: 0 })

  // Fullscreen must be requested from the user's click handler in Workspace;
  // browsers may reject requests made from an effect after user activation expires.
  // Keep fullscreen for the lifetime of presentation mode, not for each step.
  useEffect(() => () => {
    if (document.fullscreenElement) void document.exitFullscreen().catch(() => undefined)
  }, [])

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') exit()
      if (event.key === 'ArrowLeft') setStepIndex(stepIndex - 1)
      if (event.key === 'ArrowRight') setStepIndex(stepIndex + 1)
      if (event.key === 'Home') setStepIndex(0)
      if (event.code === 'Space') { event.preventDefault(); setPlayback({ playing: !playing }) }
    }
    window.addEventListener('keydown', keydown)
    return () => window.removeEventListener('keydown', keydown)
  }, [stepIndex, playing, setPlayback, setStepIndex])

  return <div className="presentation-overlay" ref={overlay}>
    <header className="presentation-header"><div><span>{plan.name}</span><h1>{stepIndex + 1}. {step.title}</h1></div><div className="presentation-toggles"><IconButton label={t('settings.legend')} active={settings.showLegend} onClick={() => setSettings({ showLegend: !settings.showLegend })}><List size={19} /></IconButton><IconButton label={t('settings.trails')} active={settings.showTrails} onClick={() => setSettings({ showTrails: !settings.showTrails })}><Footprints size={19} /></IconButton><IconButton label={t('settings.paths')} active={settings.showPaths} onClick={() => setSettings({ showPaths: !settings.showPaths })}><Route size={19} /></IconButton><IconButton label={t('action.exitPresentation')} onClick={exit}><X size={23} /></IconButton></div></header>
    <main className="presentation-pitch"><PitchBoard presentation /></main>
    <footer className="presentation-footer"><div className="presentation-note"><span>{t('presentation.instructions')}</span><p>{step.instructions || '—'}</p></div><PlaybackBar presentation /><small>{t('presentation.exitHint')}</small></footer>
  </div>
}
