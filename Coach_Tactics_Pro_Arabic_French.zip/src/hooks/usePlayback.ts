import { useEffect } from 'react'
import { activeSequence, useAppStore } from '@/store/appStore'

export function usePlayback() {
  const playing = useAppStore(state => state.playback.playing)
  const speed = useAppStore(state => state.playback.speed)
  const continuous = useAppStore(state => state.playback.continuous)
  const reducedMotion = useAppStore(state => state.settings.reducedMotion)
  const stepIndex = useAppStore(state => state.stepIndex)
  const plan = useAppStore(state => state.plan)

  useEffect(() => {
    if (!playing) return
    const sequence = activeSequence(plan)
    const next = sequence.steps[stepIndex + 1]
    if (!next) { useAppStore.getState().setPlayback({ playing: false, progress: 0 }); return }
    const systemReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const duration = reducedMotion || systemReduced ? 120 : Math.max(1, next.transition.duration)
    const startingProgress = useAppStore.getState().playback.progress
    let frame = 0
    let start = 0
    let stopped = false
    const tick = (time: number) => {
      if (stopped) return
      if (!start) start = time
      const progress = Math.min(1, startingProgress + ((time - start) * speed) / (duration * (1 - startingProgress || 1)))
      if (progress < 1) {
        useAppStore.getState().setPlayback({ progress })
        frame = requestAnimationFrame(tick)
      } else {
        useAppStore.getState().setStepIndex(stepIndex + 1)
        useAppStore.getState().setPlayback({ progress: 0, playing: continuous && stepIndex + 1 < sequence.steps.length - 1 })
      }
    }
    frame = requestAnimationFrame(tick)
    return () => { stopped = true; cancelAnimationFrame(frame) }
  }, [playing, plan, stepIndex, speed, continuous, reducedMotion])
}
