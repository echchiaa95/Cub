import type { AttackDirection, Orientation, PitchView, Point } from '@/types'

export const BASE_WIDTH = 1050
export const BASE_HEIGHT = 680

export function toBase(point: Point, direction: AttackDirection = 'ltr'): Point {
  const x = direction === 'rtl' ? 1 - point.x : point.x
  return { x: 25 + x * 1000, y: 40 + point.y * 600 }
}

export function fromBase(point: Point, direction: AttackDirection = 'ltr'): Point {
  const x = Math.max(0, Math.min(1, (point.x - 25) / 1000))
  return { x: direction === 'rtl' ? 1 - x : x, y: Math.max(0, Math.min(1, (point.y - 40) / 600)) }
}

export function baseViewBox(view: PitchView, direction: AttackDirection = 'ltr') {
  const attacking = direction === 'ltr'
  if (view === 'half') return { x: attacking ? 500 : 0, y: 0, width: 550, height: 680 }
  if (view === 'attackingThird') return { x: attacking ? 660 : 0, y: 0, width: 390, height: 680 }
  if (view === 'defensiveThird') return { x: attacking ? 0 : 660, y: 0, width: 390, height: 680 }
  if (view === 'penaltyArea') return { x: attacking ? 735 : 0, y: 65, width: 315, height: 550 }
  if (view === 'compact') return { x: 190, y: 25, width: 670, height: 630 }
  return { x: 0, y: 0, width: BASE_WIDTH, height: BASE_HEIGHT }
}

export function getViewBox(view: PitchView, orientation: Orientation, direction: AttackDirection = 'ltr') {
  const base = baseViewBox(view, direction)
  if (orientation === 'landscape') return `${base.x} ${base.y} ${base.width} ${base.height}`
  return `${base.y} ${BASE_WIDTH - base.x - base.width} ${base.height} ${base.width}`
}

export function svgPathFromBase(points: Point[], curved = false) {
  if (!points.length) return ''
  if (curved && points.length >= 3) return `M ${points[0].x} ${points[0].y} Q ${points[1].x} ${points[1].y} ${points[2].x} ${points[2].y}`
  return points.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' ')
}
