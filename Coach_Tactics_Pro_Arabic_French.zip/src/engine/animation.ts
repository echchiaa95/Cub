import type { BallState, Easing, Point, TacticalPlayer, TacticalStep, TransitionSettings } from '@/types'
import { clamp } from '@/lib/utils'

export const ease = (value: number, easing: Easing) => {
  const t = clamp(value)
  if (easing === 'easeInOut') return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
  if (easing === 'easeOut') return 1 - Math.pow(1 - t, 3)
  return t
}

export const quadraticPoint = (from: Point, to: Point, progress: number, curve = 0): Point => {
  if (from.x === to.x && from.y === to.y) return { x: from.x, y: from.y }
  const t = clamp(progress)
  const control = {
    x: (from.x + to.x) / 2 - (to.y - from.y) * curve,
    y: (from.y + to.y) / 2 + (to.x - from.x) * curve,
  }
  const inv = 1 - t
  return {
    x: inv * inv * from.x + 2 * inv * t * control.x + t * t * to.x,
    y: inv * inv * from.y + 2 * inv * t * control.y + t * t * to.y,
  }
}

const timedProgress = (elapsed: number, duration: number, delay: number, easing: Easing) => {
  if (elapsed <= delay) return 0
  if (duration <= 0 || elapsed >= delay + duration) return 1
  return ease((elapsed - delay) / duration, easing)
}

export function interpolateStep(from: TacticalStep, to: TacticalStep, progress: number): TacticalStep {
  const transition: TransitionSettings = to.transition
  const elapsed = clamp(progress) * transition.duration
  const instant = transition.instant
  const players = to.players.map(target => {
    const source = from.players.find(player => player.id === target.id) ?? target
    const path = transition.playerPaths[target.id]
    const delay = instant ? 0 : path?.delay ?? 0
    const duration = instant ? 0 : path?.duration ?? transition.duration
    const local = timedProgress(elapsed, duration, delay, path?.easing ?? transition.easing)
    const point = quadraticPoint(source, target, local, instant ? 0 : path?.curve ?? 0)
    return { ...target, x: point.x, y: point.y, visible: local < .5 ? source.visible : target.visible }
  })
  const ballPath = transition.ballPath
  const ballProgress = instant ? 1 : timedProgress(elapsed, ballPath.duration, ballPath.delay, ballPath.easing)
  const ball: BallState = { ...to.ball, ...quadraticPoint(from.ball, to.ball, ballProgress, instant ? 0 : ballPath.curve) }
  return { ...to, players, ball, title: progress < .5 ? from.title : to.title, instructions: progress < .5 ? from.instructions : to.instructions }
}

export const movementTrail = (from: TacticalPlayer, to: TacticalPlayer, curve = 0) => {
  const points = Array.from({ length: 17 }, (_, index) => quadraticPoint(from, to, index / 16, curve))
  return points.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' ')
}
