import { useCallback } from 'react'
import en from './en'
import fr from './fr'
import ar from './ar'
import { useAppStore } from '@/store/appStore'

export type TranslationKey = keyof typeof en
const dictionaries = { en, fr, ar }

export function translate(language: 'en' | 'fr' | 'ar', key: string, variables?: Record<string, string | number>) {
  const dictionary = dictionaries[language] as Record<string, string>
  let value = dictionary[key] ?? (en as Record<string, string>)[key] ?? key
  if (variables) Object.entries(variables).forEach(([name, replacement]) => { value = value.replaceAll(`{${name}}`, String(replacement)) })
  return value
}

export function useT() {
  const language = useAppStore(state => state.settings.language)
  return useCallback((key: string, variables?: Record<string, string | number>) => translate(language, key, variables), [language])
}
