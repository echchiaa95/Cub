import type { BackupFile, TacticalPlan } from '@/types'
import { backupSchema, tacticalPlanSchema } from './schema'
import { db } from './database'
import { downloadBlob, uid } from '@/lib/utils'

export async function readJsonFile(file: File): Promise<unknown> {
  try { return JSON.parse(await file.text()) } catch { throw new Error('Invalid JSON file') }
}

export async function importPlanFile(file: File): Promise<TacticalPlan> {
  const parsed = tacticalPlanSchema.safeParse(await readJsonFile(file))
  if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? 'Invalid plan')
  const plan = parsed.data as TacticalPlan
  if (await db.plans.get(plan.id)) {
    const now = new Date().toISOString()
    return { ...plan, id: uid('plan'), name: `${plan.name} (imported)`, createdAt: now, updatedAt: now, lastOpenedAt: now }
  }
  return plan
}

export async function createBackup(): Promise<BackupFile> {
  const [plans, formations, templates, settingRow] = await Promise.all([db.plans.toArray(), db.formations.toArray(), db.templates.toArray(), db.settings.get('application')])
  return {
    backupVersion: 1, createdAt: new Date().toISOString(), plans, formations, templates,
    settings: settingRow?.value ?? JSON.parse(localStorage.getItem('coach-settings') ?? '{}'),
  }
}

export async function downloadBackup() {
  const backup = await createBackup()
  downloadBlob(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }), `coach-tactics-backup-${new Date().toISOString().slice(0, 10)}.json`)
}

export async function parseBackupFile(file: File): Promise<BackupFile> {
  const parsed = backupSchema.safeParse(await readJsonFile(file))
  if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? 'Invalid backup')
  return parsed.data as BackupFile
}

export async function restoreBackup(backup: BackupFile) {
  await db.transaction('rw', [db.plans, db.formations, db.templates, db.settings], async () => {
    await Promise.all([db.plans.clear(), db.formations.clear(), db.templates.clear(), db.settings.clear()])
    await db.plans.bulkPut(backup.plans)
    await db.formations.bulkPut(backup.formations)
    await db.templates.bulkPut(backup.templates)
    await db.settings.put({ id: 'application', value: backup.settings })
  })
  localStorage.setItem('coach-settings', JSON.stringify(backup.settings))
}
