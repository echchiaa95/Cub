import type { ApplicationSettings, TacticalDrawing, TacticalPlan, TacticalStep } from '@/types'
import { downloadBlob, safeFilename } from '@/lib/utils'

export interface PngOptions { labels: boolean; teams: boolean; legend: boolean; trails: boolean; selection: boolean; interface: boolean }

const svgStyle = `
  :root{--pitch-outer:#123b33;--pitch-green:#17624b;--pitch-stripe:rgba(255,255,255,.025);--pitch-line:#f1f5e9;--pitch-grid:rgba(255,255,255,.2);--pitch-text-bg:#123b33;--accent:#bef264;--surface:#17211f;--text:#eef4ed;--marker-ring:#f5f7ee;--ball:#f8fafc;--ball-ring:#17211f;--ball-trail:#f8fafc;--legend-text:#e8efe5;--legend-pass:#f8fafc;--legend-opponent:#fb7185;--legend-press:#fbbf24;--annotation-text:#17211f}
  text{font-family:Arial,sans-serif}`

function prepareSvg(svg: SVGSVGElement, options: PngOptions) {
  const clone = svg.cloneNode(true) as SVGSVGElement
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
  clone.setAttribute('width', '1600')
  clone.setAttribute('height', '1036')
  const style = document.createElementNS('http://www.w3.org/2000/svg', 'style')
  style.textContent = svgStyle
  clone.insertBefore(style, clone.firstChild)
  if (!options.labels) clone.querySelectorAll('[data-layer="teamA"] text + text, [data-layer="teamB"] text + text').forEach(node => node.remove())
  if (!options.teams) clone.querySelectorAll('[data-team-labels]').forEach(node => node.remove())
  if (!options.legend) clone.querySelectorAll('[data-legend]').forEach(node => node.remove())
  if (!options.trails) clone.querySelectorAll('[data-layer="trails"]').forEach(node => node.remove())
  if (!options.selection) clone.querySelectorAll('[data-selection-overlay]').forEach(node => node.remove())
  return clone
}

async function rasterizeSvg(svg: SVGSVGElement | string, width = 1600): Promise<HTMLCanvasElement> {
  const source = typeof svg === 'string' ? svg : new XMLSerializer().serializeToString(svg)
  const blob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  try {
    const image = new Image()
    await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error('Could not rasterize board')); image.src = url })
    const viewHeight = typeof svg === 'string' ? 1036 : 1036
    const canvas = document.createElement('canvas')
    canvas.width = width; canvas.height = Math.round(width * viewHeight / 1600)
    const context = canvas.getContext('2d')!
    context.fillStyle = '#123b33'; context.fillRect(0, 0, canvas.width, canvas.height)
    context.drawImage(image, 0, 0, canvas.width, canvas.height)
    return canvas
  } finally { URL.revokeObjectURL(url) }
}

export async function exportPng(svg: SVGSVGElement, plan: TacticalPlan, options: PngOptions) {
  let canvas: HTMLCanvasElement
  if (options.interface) {
    const { toBlob } = await import('html-to-image')
    const workspace = document.querySelector<HTMLElement>('.workspace')
    if (!workspace) throw new Error('Workspace unavailable')
    const blob = await toBlob(workspace, {
      backgroundColor: '#101b1a',
      pixelRatio: Math.min(2, 1800 / workspace.clientWidth),
      skipFonts: true,
    })
    if (!blob) throw new Error('PNG encoding failed')
    downloadBlob(blob, `${safeFilename(plan.name)}.png`)
    return
  }
  canvas = await rasterizeSvg(prepareSvg(svg, options), 1800)
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('PNG encoding failed')), 'image/png'))
  downloadBlob(blob, `${safeFilename(plan.name)}.png`)
}

const escapeXml = (value: string) => value.replace(/[<>&'"]/g, char => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' })[char]!)
const basePoint = (point: { x: number; y: number }) => ({ x: 25 + point.x * 1000, y: 40 + point.y * 600 })

function staticDrawing(drawing: TacticalDrawing) {
  const points = drawing.points.map(basePoint)
  const start = points[0]; const end = points.at(-1) ?? start
  const common = `stroke="${drawing.color}" stroke-width="${drawing.width}" stroke-dasharray="${drawing.dash}" opacity="${drawing.opacity}" fill="none"`
  const curved = ['curvedArrow', 'dribble', 'overlap', 'underlap'].includes(drawing.type)
  if (curved && points.length === 2) points.splice(1, 0, { x: (start.x + end.x) / 2 - (end.y - start.y) * .18, y: (start.y + end.y) / 2 + (end.x - start.x) * .18 })
  const marker = drawing.arrow ? `marker-end="url(#arrow-${drawing.id})"` : ''
  const defs = drawing.arrow ? `<defs><marker id="arrow-${drawing.id}" markerWidth="14" markerHeight="14" refX="11" refY="6" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0L12 6L0 12Z" fill="${drawing.color}"/></marker></defs>` : ''
  if (drawing.type === 'circle') return `${defs}<ellipse cx="${(start.x + end.x) / 2}" cy="${(start.y + end.y) / 2}" rx="${Math.abs(end.x - start.x) / 2}" ry="${Math.abs(end.y - start.y) / 2}" ${common} fill="${drawing.fill}" fill-opacity="${drawing.fillOpacity}"/>`
  if (drawing.type === 'rectangle' || drawing.type === 'zone') return `${defs}<rect x="${Math.min(start.x, end.x)}" y="${Math.min(start.y, end.y)}" width="${Math.abs(end.x - start.x)}" height="${Math.abs(end.y - start.y)}" ${common} fill="${drawing.fill}" fill-opacity="${drawing.fillOpacity}"/>`
  if (drawing.type === 'polygon') return `${defs}<polygon points="${points.map(point => `${point.x},${point.y}`).join(' ')}" ${common} fill="${drawing.fill}" fill-opacity="${drawing.fillOpacity}"/>`
  if (drawing.type === 'text') return `<text x="${start.x}" y="${start.y}" fill="${drawing.color}" font-size="${drawing.width * 5 + 10}" font-weight="650">${escapeXml(drawing.label)}</text>`
  if (drawing.type === 'number') return `<circle cx="${start.x}" cy="${start.y}" r="${drawing.width * 3 + 8}" fill="${drawing.color}"/><text x="${start.x}" y="${start.y + 5}" text-anchor="middle" fill="#17211f" font-size="16" font-weight="800">${escapeXml(drawing.label)}</text>`
  const path = curved && points.length >= 3 ? `M${start.x},${start.y}Q${points[1].x},${points[1].y},${end.x},${end.y}` : points.map((point, index) => `${index ? 'L' : 'M'}${point.x},${point.y}`).join(' ')
  return `${defs}<path d="${path}" ${common} ${marker}/>`
}

export function renderStepSvg(step: TacticalStep, plan: TacticalPlan, settings: ApplicationSettings) {
  const players = step.players.filter(player => player.visible && (player.teamId === 'A' ? plan.teamA.visible : plan.teamB.visible)).map(player => {
    const point = basePoint(player); const team = player.teamId === 'A' ? plan.teamA : plan.teamB
    return `<g transform="translate(${point.x} ${point.y})"><circle r="${settings.markerSize}" fill="${team.color}" stroke="#f5f7ee" stroke-width="2.2"/><text text-anchor="middle" y="6" fill="${team.textColor}" font-size="${settings.markerSize * .85}" font-weight="800">${player.number}</text>${settings.showLabels && (player.name || player.position) ? `<text text-anchor="middle" y="${settings.markerSize + 17}" fill="#f1f5e9" font-size="12" font-weight="700">${escapeXml(player.name || player.position)}</text>` : ''}</g>`
  }).join('')
  const ballPoint = basePoint(step.ball)
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1036" viewBox="0 0 1050 680"><style>${svgStyle}</style><rect width="1050" height="680" rx="22" fill="#123b33"/><rect x="25" y="40" width="1000" height="600" fill="#17624b"/>${Array.from({ length: 10 }, (_, index) => `<rect x="${25 + index * 100}" y="40" width="100" height="600" fill="${index % 2 ? 'rgba(255,255,255,.025)' : 'transparent'}"/>`).join('')}<g fill="none" stroke="#f1f5e9" stroke-width="2.4"><rect x="25" y="40" width="1000" height="600"/><path d="M525 40V640"/><circle cx="525" cy="340" r="91.5"/><path d="M25 175H190V505H25 M1025 175H860V505H1025 M25 257.5H80V422.5H25 M1025 257.5H970V422.5H1025 M190 256C235 275 235 405 190 424 M860 256C815 275 815 405 860 424 M17 295H25V385H17 M1033 295H1025V385H1033"/></g><g fill="#f1f5e9"><circle cx="525" cy="340" r="3.5"/><circle cx="135" cy="340" r="3.5"/><circle cx="915" cy="340" r="3.5"/></g>${step.drawings.map(staticDrawing).join('')}${players}${step.ball.visible ? `<g transform="translate(${ballPoint.x} ${ballPoint.y})"><circle r="11" fill="#f8fafc" stroke="#17211f" stroke-width="2"/><path d="M0-5L5-1L3 5H-3L-5-1Z" fill="#17211f"/></g>` : ''}</svg>`
}

function wrapCanvasText(context: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number, maxLines = 4) {
  const paragraphs = text.split('\n')
  let lineY = y; let count = 0
  for (const paragraph of paragraphs) {
    const words = paragraph.split(/\s+/); let line = ''
    for (const word of words) {
      const test = line ? `${line} ${word}` : word
      if (context.measureText(test).width > maxWidth && line) {
        context.fillText(line, x, lineY); lineY += lineHeight; count++; line = word
        if (count >= maxLines) return
      } else line = test
    }
    if (line) { context.fillText(line, x, lineY); lineY += lineHeight; count++ }
    if (count >= maxLines) return
  }
}

export async function exportPdf(plan: TacticalPlan, steps: TacticalStep[], settings: ApplicationSettings) {
  const { jsPDF } = await import('jspdf')
  const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4', compress: true })
  for (let index = 0; index < steps.length; index++) {
    const step = steps[index]
    const board = await rasterizeSvg(renderStepSvg(step, plan, settings), 1400)
    const page = document.createElement('canvas'); page.width = 1600; page.height = 1131
    const context = page.getContext('2d')!
    context.fillStyle = '#f4f6f1'; context.fillRect(0, 0, page.width, page.height)
    context.fillStyle = '#101b1a'; context.fillRect(0, 0, page.width, 112)
    context.fillStyle = '#bef264'; context.font = '700 24px "IBM Plex Mono", monospace'; context.fillText('COACH TACTICS PRO', 64, 45)
    context.fillStyle = '#f4f6f1'; context.font = '700 34px "IBM Plex Sans", Arial, sans-serif'; context.fillText(plan.name, 64, 88)
    context.direction = settings.language === 'ar' ? 'rtl' : 'ltr'
    context.textAlign = settings.language === 'ar' ? 'right' : 'left'
    const textX = settings.language === 'ar' ? 1536 : 64
    context.fillStyle = '#17211f'; context.font = '700 29px "IBM Plex Sans", Arial, sans-serif'
    context.fillText(`${index + 1} / ${steps.length} — ${step.title}`, textX, 160)
    context.drawImage(board, 100, 190, 1400, 905 * (680 / 1050))
    context.fillStyle = '#52615b'; context.font = '600 18px "IBM Plex Mono", monospace'
    context.fillText(`${plan.teamA.name}${plan.opponentName ? `  vs  ${plan.opponentName}` : ''}`, textX, 840)
    context.fillStyle = '#17211f'; context.font = '400 24px "IBM Plex Sans", Arial, sans-serif'
    wrapCanvasText(context, step.instructions || '—', textX, 900, 1472, 36, 4)
    const image = page.toDataURL('image/jpeg', .94)
    if (index > 0) pdf.addPage('a4', 'landscape')
    pdf.addImage(image, 'JPEG', 0, 0, 297, 210, undefined, 'FAST')
  }
  pdf.save(`${safeFilename(plan.name)}.pdf`)
}

export function exportPlanJson(plan: TacticalPlan) {
  downloadBlob(new Blob([JSON.stringify(plan, null, 2)], { type: 'application/json' }), `${safeFilename(plan.name)}.json`)
}
