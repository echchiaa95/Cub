import { z } from 'zod'

const point = z.object({ x: z.number().min(-.2).max(1.2), y: z.number().min(-.2).max(1.2) })
const player = point.extend({
  id: z.string().min(1), teamId: z.enum(['A', 'B']), number: z.number().int().min(1).max(99),
  name: z.string().max(80), position: z.string().max(20), locked: z.boolean(), visible: z.boolean(), trail: z.boolean(),
})
const team = z.object({ id: z.enum(['A', 'B']), name: z.string().max(80), color: z.string().regex(/^#[0-9a-fA-F]{6}$/), textColor: z.string().regex(/^#[0-9a-fA-F]{6}$/), visible: z.boolean(), formation: z.string() })
const drawing = z.object({
  id: z.string(), type: z.string(), points: z.array(point).max(500), color: z.string(), width: z.number().min(1).max(30),
  dash: z.string().max(30), arrow: z.boolean(), opacity: z.number().min(0).max(1), fill: z.string(),
  fillOpacity: z.number().min(0).max(1), label: z.string().max(300), locked: z.boolean(),
})
const movement = z.object({ playerId: z.string(), delay: z.number().min(0).max(60000), duration: z.number().min(0).max(60000), easing: z.enum(['linear', 'easeInOut', 'easeOut']), curve: z.number().min(-2).max(2) })
const step = z.object({
  id: z.string(), title: z.string().max(160), instructions: z.string().max(10000), players: z.array(player).max(60),
  ball: point.extend({ visible: z.boolean(), trail: z.boolean() }), drawings: z.array(drawing).max(500), duration: z.number().min(100).max(60000),
  transition: z.object({ duration: z.number().min(0).max(60000), easing: z.enum(['linear', 'easeInOut', 'easeOut']), instant: z.boolean(), playerPaths: z.record(z.string(), movement), ballPath: z.object({ delay: z.number().min(0).max(60000), duration: z.number().min(0).max(60000), easing: z.enum(['linear', 'easeInOut', 'easeOut']), curve: z.number().min(-2).max(2), showPath: z.boolean() }) }),
})
const sequence = z.object({ id: z.string(), name: z.string().max(160), category: z.enum(['attacking', 'defensive', 'transitions', 'setPieces', 'custom']), steps: z.array(step).min(1).max(200) })
export const tacticalPlanSchema = z.object({
  schemaVersion: z.literal(1), id: z.string(), name: z.string().min(1).max(160), description: z.string().max(5000),
  category: z.enum(['attacking', 'defensive', 'transitions', 'setPieces', 'custom']), formation: z.string(), teamA: team, teamB: team,
  opponentName: z.string().max(160), matchLabel: z.string().max(160), sequences: z.array(sequence).min(1).max(100), activeSequenceId: z.string(),
  createdAt: z.string(), updatedAt: z.string(), favorite: z.boolean(), lastOpenedAt: z.string(),
}).superRefine((plan, ctx) => {
  if (!plan.sequences.some(item => item.id === plan.activeSequenceId)) ctx.addIssue({ code: 'custom', message: 'Active sequence does not exist' })
  for (const item of plan.sequences.flatMap(sequence => sequence.steps)) {
    const ids = item.players.map(player => player.id)
    if (new Set(ids).size !== ids.length) ctx.addIssue({ code: 'custom', message: 'Player IDs must be unique within each step' })
  }
})

const formationSchema = z.object({ id: z.string(), name: z.string(), custom: z.boolean(), positions: z.array(point.extend({ number: z.number().int().min(1).max(99), position: z.string() })).max(30) })
const settingsSchema = z.object({ language: z.enum(['en', 'fr', 'ar']), theme: z.enum(['dark', 'light']), orientation: z.enum(['landscape', 'portrait']), attackDirection: z.enum(['ltr', 'rtl']), pitchView: z.enum(['full', 'half', 'attackingThird', 'defensiveThird', 'penaltyArea', 'compact']), showGrid: z.boolean(), showLabels: z.boolean(), showTrails: z.boolean(), showLegend: z.boolean(), showPaths: z.boolean(), showTeamLabels: z.boolean(), markerSize: z.number(), markerShape: z.enum(['circle', 'shirt']), reducedMotion: z.boolean() })
export const backupSchema = z.object({ backupVersion: z.literal(1), createdAt: z.string(), plans: z.array(tacticalPlanSchema), formations: z.array(formationSchema), settings: settingsSchema, templates: z.array(z.object({ id: z.string(), name: z.string(), createdAt: z.string(), sequence })) })
export type ImportedPlan = z.infer<typeof tacticalPlanSchema>
