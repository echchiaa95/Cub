import Dexie, { type Table } from 'dexie'
import type { ApplicationSettings, CustomTemplate, Formation, TacticalPlan } from '@/types'

export class CoachDatabase extends Dexie {
  plans!: Table<TacticalPlan, string>
  formations!: Table<Formation, string>
  templates!: Table<CustomTemplate, string>
  settings!: Table<{ id: string; value: ApplicationSettings }, string>

  constructor() {
    super('coach-tactics-pro')
    this.version(1).stores({
      plans: 'id, name, updatedAt, favorite, lastOpenedAt, category',
      formations: 'id, name, custom',
      templates: 'id, name, createdAt',
      settings: 'id',
    })
    this.version(2).stores({
      plans: 'id, name, updatedAt, favorite, lastOpenedAt, category, matchLabel',
      formations: 'id, name, custom',
      templates: 'id, name, createdAt',
      settings: 'id',
    })
  }
}

export const db = new CoachDatabase()

export async function savePlanTransaction(plan: TacticalPlan) {
  await db.plans.put(structuredClone(plan))
  return plan
}

export async function listPlans() {
  return db.plans.orderBy('updatedAt').reverse().toArray()
}

export async function deletePlanTransaction(id: string) {
  await db.plans.delete(id)
}
