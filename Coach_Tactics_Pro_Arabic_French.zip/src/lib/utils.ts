import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import type { Point } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const uid = (prefix = 'id') => `${prefix}-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`}`
export const clamp = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value))
export const clone = <T,>(value: T): T => structuredClone(value)
export const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y)
export const downloadBlob = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  anchor.click()
  window.setTimeout(() => URL.revokeObjectURL(url), 1000)
}
export const safeFilename = (name: string) => name.trim().replace(/[^a-zA-Z0-9\u0600-\u06FF_-]+/g, '-').slice(0, 80) || 'tactical-plan'
