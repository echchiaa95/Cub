export type Point = { x: number; y: number }
export type TeamId = 'A' | 'B'
export type Language = 'en' | 'fr' | 'ar'
export type Theme = 'dark' | 'light'
export type PitchView = 'full' | 'half' | 'attackingThird' | 'defensiveThird' | 'penaltyArea' | 'compact'
export type Orientation = 'landscape' | 'portrait'
export type AttackDirection = 'ltr' | 'rtl'
export type Easing = 'linear' | 'easeInOut' | 'easeOut'
export type Tool =
  | 'select' | 'pan' | 'straightArrow' | 'curvedArrow' | 'dashedArrow' | 'pass'
  | 'run' | 'ballPath' | 'dribble' | 'defensiveMove' | 'press' | 'overlap'
  | 'underlap' | 'freehand' | 'circle' | 'rectangle' | 'polygon' | 'zone'
  | 'defensiveLine' | 'offsideLine' | 'text' | 'number' | 'eraser'

export interface TacticalPlayer {
  id: string
  teamId: TeamId
  number: number
  name: string
  position: string
  x: number
  y: number
  locked: boolean
  visible: boolean
  trail: boolean
}

export interface TeamConfiguration {
  id: TeamId
  name: string
  color: string
  textColor: string
  visible: boolean
  formation: string
}

export interface BallState extends Point {
  visible: boolean
  trail: boolean
}

export type DrawingType = Exclude<Tool, 'select' | 'pan' | 'eraser'>

export interface TacticalDrawing {
  id: string
  type: DrawingType
  points: Point[]
  color: string
  width: number
  dash: string
  arrow: boolean
  opacity: number
  fill: string
  fillOpacity: number
  label: string
  locked: boolean
}

export interface MovementPath {
  playerId: string
  delay: number
  duration: number
  easing: Easing
  curve: number
}

export interface BallMovementPath {
  delay: number
  duration: number
  easing: Easing
  curve: number
  showPath: boolean
}

export interface TransitionSettings {
  duration: number
  easing: Easing
  instant: boolean
  playerPaths: Record<string, MovementPath>
  ballPath: BallMovementPath
}

export interface TacticalStep {
  id: string
  title: string
  instructions: string
  players: TacticalPlayer[]
  ball: BallState
  drawings: TacticalDrawing[]
  duration: number
  transition: TransitionSettings
}

export type TacticalCategory = 'attacking' | 'defensive' | 'transitions' | 'setPieces' | 'custom'

export interface TacticalSequence {
  id: string
  name: string
  category: TacticalCategory
  steps: TacticalStep[]
}

export interface TacticalPlan {
  schemaVersion: 1
  id: string
  name: string
  description: string
  category: TacticalCategory
  formation: string
  teamA: TeamConfiguration
  teamB: TeamConfiguration
  opponentName: string
  matchLabel: string
  sequences: TacticalSequence[]
  activeSequenceId: string
  createdAt: string
  updatedAt: string
  favorite: boolean
  lastOpenedAt: string
}

export interface Formation {
  id: string
  name: string
  custom: boolean
  positions: Array<Point & { number: number; position: string }>
}

export interface ScenarioTemplate {
  id: string
  nameKey: string
  descriptionKey: string
  category: TacticalCategory
  pitchView: PitchView
  pattern: 'buildUp' | 'wide' | 'central' | 'press' | 'block' | 'transition' | 'corner' | 'freeKick' | 'throwIn' | 'penalty'
}

export interface ApplicationSettings {
  language: Language
  theme: Theme
  orientation: Orientation
  attackDirection: AttackDirection
  pitchView: PitchView
  showGrid: boolean
  showLabels: boolean
  showTrails: boolean
  showLegend: boolean
  showPaths: boolean
  showTeamLabels: boolean
  markerSize: number
  markerShape: 'circle' | 'shirt'
  reducedMotion: boolean
}

export interface CustomTemplate {
  id: string
  name: string
  createdAt: string
  sequence: TacticalSequence
}

export interface BackupFile {
  backupVersion: 1
  createdAt: string
  plans: TacticalPlan[]
  formations: Formation[]
  settings: ApplicationSettings
  templates: CustomTemplate[]
}

export type SaveStatus = 'idle' | 'saving' | 'saved' | 'failed' | 'unavailable'
export type TacticalLayer = 'pitch' | 'teamA' | 'teamB' | 'ball' | 'paths' | 'zones' | 'annotations' | 'overlays'
