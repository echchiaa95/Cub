import { useRef, useState } from 'react'
import { DatabaseBackup, Download, Globe2, HardDrive, Info, Moon, RotateCcw, Sun, Upload } from 'lucide-react'
import { toast } from 'sonner'
import type { BackupFile } from '@/types'
import { useAppStore } from '@/store/appStore'
import { downloadBackup, parseBackupFile, restoreBackup } from '@/services/transfer'
import { useT } from '@/i18n'
import { Button, Field, Modal, Panel, Toggle } from '@/components/Controls'

export function SettingsPage() {
  const t = useT()
  const settings = useAppStore(state => state.settings)
  const setSettings = useAppStore(state => state.setSettings)
  const [backup, setBackup] = useState<BackupFile | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  return <main className="page settings-page">
    <header className="page-heading"><div><span className="section-kicker">{t('panel.settings')}</span><h1>{t('settings.title')}</h1><p>{t('app.tagline')}</p></div></header>
    <div className="settings-grid">
      <Panel title={t('settings.appearance')}><div className="form-stack">
        <Field label={t('settings.language')}><div className="setting-with-icon"><Globe2 size={18} /><select value={settings.language} onChange={event => setSettings({ language: event.target.value as typeof settings.language })}><option value="en">English</option><option value="fr">Français</option><option value="ar">العربية</option></select></div></Field>
        <div className="theme-choices"><button className={settings.theme === 'dark' ? 'is-active' : ''} onClick={() => setSettings({ theme: 'dark' })}><Moon size={19} />{t('settings.dark')}</button><button className={settings.theme === 'light' ? 'is-active' : ''} onClick={() => setSettings({ theme: 'light' })}><Sun size={19} />{t('settings.light')}</button></div>
        <Toggle label={t('settings.reducedMotion')} checked={settings.reducedMotion} onChange={checked => setSettings({ reducedMotion: checked })} />
      </div></Panel>
      <Panel title={t('settings.pitch')}><div className="form-stack">
        <Toggle label={t('settings.legend')} checked={settings.showLegend} onChange={checked => setSettings({ showLegend: checked })} />
        <Toggle label={t('settings.paths')} checked={settings.showPaths} onChange={checked => setSettings({ showPaths: checked })} />
        <Toggle label={t('settings.trails')} checked={settings.showTrails} onChange={checked => setSettings({ showTrails: checked })} />
        <Toggle label={t('settings.teamLabels')} checked={settings.showTeamLabels} onChange={checked => setSettings({ showTeamLabels: checked })} />
        <Toggle label={t('pitch.grid')} checked={settings.showGrid} onChange={checked => setSettings({ showGrid: checked })} />
      </div></Panel>
      <Panel title={t('settings.storage')}><div className="form-stack">
        <div className="storage-note"><HardDrive size={21} /><p>{t('settings.storageNote')}</p></div>
        <Button onClick={() => void downloadBackup().then(() => toast.success(t('export.success')))}><Download size={17} />{t('settings.backup')}</Button>
        <Button onClick={() => fileRef.current?.click()}><Upload size={17} />{t('settings.restore')}</Button>
        <input ref={fileRef} hidden type="file" accept="application/json,.json" onChange={async event => { const file = event.target.files?.[0]; if (!file) return; try { setBackup(await parseBackupFile(file)) } catch { toast.error(t('messages.invalidFile')) } event.target.value = '' }} />
      </div></Panel>
      <Panel title={t('status.offline')}><div className="form-stack"><div className="storage-note"><Info size={21} /><p>{t('settings.offlineNote')}</p></div><div className="storage-note"><DatabaseBackup size={21} /><p>{t('settings.storageNote')}</p></div></div></Panel>
    </div>
    {backup && <Modal title={t('settings.restoreTitle')} onClose={() => setBackup(null)}><p className="modal-copy">{t('settings.restoreBody')}</p><div className="restore-summary"><span>{backup.plans.length} {t('nav.library')}</span><span>{new Intl.DateTimeFormat(settings.language, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(backup.createdAt))}</span></div><div className="modal-actions"><Button onClick={() => void downloadBackup()}><Download size={16} />{t('settings.backup')}</Button><Button variant="danger" onClick={async () => { await restoreBackup(backup); setBackup(null); toast.success(t('export.backupSuccess')); window.setTimeout(() => window.location.reload(), 500) }}><RotateCcw size={16} />{t('action.restore')}</Button></div></Modal>}
  </main>
}
