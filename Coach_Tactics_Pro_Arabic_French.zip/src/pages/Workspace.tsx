import { useEffect, useRef, useState } from 'react'
import { CircleDot, Grid3X3, Play, SlidersHorizontal, Users, View } from 'lucide-react'
import { activeStep, useAppStore } from '@/store/appStore'
import { useT } from '@/i18n'
import { DrawingToolbar } from '@/components/DrawingToolbar'
import { PitchBoard } from '@/components/PitchBoard'
import { Inspector } from '@/components/Inspector'
import { PlaybackBar } from '@/components/PlaybackBar'
import { SequenceTimeline } from '@/components/SequenceTimeline'
import { Button, IconButton } from '@/components/Controls'

export function Workspace() {
  const t = useT()
  const plan = useAppStore(state => state.plan)
  const stepIndex = useAppStore(state => state.stepIndex)
  const settings = useAppStore(state => state.settings)
  const presentation = useAppStore(state => state.playback.presentation)
  const store = useAppStore
  const step = activeStep(plan, stepIndex)
  const [mobileInspector, setMobileInspector] = useState(false)
  const svgRef = useRef<SVGSVGElement>(null)

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || presentation) return
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? store.getState().redo() : store.getState().undo() }
      if (event.key === 'Delete') {
        const selectedDrawingId = store.getState().selectedDrawingId
        if (selectedDrawingId !== null) {
          store.getState().deleteDrawing(selectedDrawingId)
        }
      }
      if (event.code === 'Space') { event.preventDefault(); store.getState().setPlayback({ playing: !store.getState().playback.playing }) }
      if (event.key === 'ArrowLeft') store.getState().setStepIndex(stepIndex - 1)
      if (event.key === 'ArrowRight') store.getState().setStepIndex(stepIndex + 1)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [stepIndex, presentation, store])

  return <main className="workspace">
    <div className="workspace-planbar">
      <div className="plan-identity"><input aria-label={t('plan.title')} value={plan.name} onChange={event => store.getState().updateMetadata({ name: event.target.value })} /><span>{step.title}</span></div>
      <div className="pitch-config">
        <label><View size={15} /><select aria-label={t('pitch.full')} value={settings.pitchView} onChange={event => store.getState().setSettings({ pitchView: event.target.value as typeof settings.pitchView })}>{['full', 'half', 'attackingThird', 'defensiveThird', 'penaltyArea', 'compact'].map(view => <option key={view} value={view}>{t(`pitch.${view}`)}</option>)}</select></label>
        <label><select aria-label={t('pitch.landscape')} value={settings.orientation} onChange={event => store.getState().setSettings({ orientation: event.target.value as typeof settings.orientation })}><option value="landscape">{t('pitch.landscape')}</option><option value="portrait">{t('pitch.portrait')}</option></select></label>
        <label><select aria-label={t('pitch.direction')} value={settings.attackDirection} onChange={event => store.getState().setSettings({ attackDirection: event.target.value as typeof settings.attackDirection })}><option value="ltr">{t('pitch.leftToRight')}</option><option value="rtl">{t('pitch.rightToLeft')}</option></select></label>
        <IconButton label={t('pitch.grid')} active={settings.showGrid} onClick={() => store.getState().setSettings({ showGrid: !settings.showGrid })}><Grid3X3 size={17} /></IconButton>
        <IconButton label={step.ball.visible ? t('ball.hide') : t('ball.show')} active={step.ball.visible} onClick={() => store.getState().updateBall({ visible: !step.ball.visible })}><CircleDot size={17} /></IconButton>
        <Button variant="primary" size="small" onClick={() => { void document.documentElement.requestFullscreen?.().catch(() => undefined); store.getState().setPlayback({ presentation: true, playing: false, progress: 0 }) }}><Play size={16} />{t('action.presentation')}</Button>
      </div>
    </div>
    <div className="workspace-editor">
      <DrawingToolbar />
      <section className="board-column">
        <div className="board-stage"><PitchBoard svgRef={svgRef} /><div className="board-mobile-actions"><IconButton label={t('panel.players')} onClick={() => setMobileInspector(true)}><SlidersHorizontal size={19} /></IconButton></div></div>
        <PlaybackBar />
      </section>
      <div className={`inspector-wrap ${mobileInspector ? 'mobile-open' : ''}`}><Inspector onClose={() => setMobileInspector(false)} /></div>
    </div>
    <SequenceTimeline />
    <button className="mobile-inspector-fab" onClick={() => setMobileInspector(true)}><Users size={19} /><span>{t('panel.players')}</span></button>
  </main>
}
