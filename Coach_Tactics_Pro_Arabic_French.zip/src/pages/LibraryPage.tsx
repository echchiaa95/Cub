import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import { Clock, Copy, FolderOpen, Heart, Pencil, Plus, Search, Star, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { useAppStore } from '@/store/appStore'
import { clone, uid } from '@/lib/utils'
import { db, savePlanTransaction } from '@/services/database'
import { useT } from '@/i18n'
import { Button, EmptyState, IconButton, Modal } from '@/components/Controls'

export function LibraryPage() {
  const t = useT()
  const navigate = useNavigate()
  const plans = useAppStore(state => state.plans)
  const current = useAppStore(state => state.plan)
  const language = useAppStore(state => state.settings.language)
  const store = useAppStore()
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<'all' | 'favorites' | 'recent'>('all')
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [renameId, setRenameId] = useState<string | null>(null)
  const [renameName, setRenameName] = useState('')
  const refresh = async () => useAppStore.setState({ plans: await db.plans.toArray() })
  const filtered = useMemo(() => plans.filter(plan => {
    const haystack = `${plan.name} ${plan.teamA.name} ${plan.teamB.name} ${plan.matchLabel}`.toLowerCase()
    return haystack.includes(query.toLowerCase()) && (filter === 'all' || filter === 'favorites' && plan.favorite || filter === 'recent' && Date.now() - new Date(plan.lastOpenedAt).getTime() < 1000 * 60 * 60 * 24 * 30)
  }).sort((a, b) => (filter === 'recent' ? b.lastOpenedAt.localeCompare(a.lastOpenedAt) : b.updatedAt.localeCompare(a.updatedAt))), [plans, query, filter])
  const duplicate = async (id: string) => {
    const source = plans.find(plan => plan.id === id); if (!source) return
    const now = new Date().toISOString()
    await savePlanTransaction({ ...clone(source), id: uid('plan'), name: `${source.name} — copy`, createdAt: now, updatedAt: now, lastOpenedAt: now })
    await refresh(); toast.success(t('messages.copied'))
  }
  return <main className="page library-page">
    <header className="page-heading"><div><span className="section-kicker">{t('panel.library')}</span><h1>{t('nav.library')}</h1><p>{plans.length} {t('nav.library').toLowerCase()} · {t('status.localOnly')}</p></div><Button variant="primary" onClick={() => { store.newPlan(t('library.new')); navigate('/') }}><Plus size={18} />{t('library.new')}</Button></header>
    <div className="library-tools"><label className="search-box"><Search size={18} /><input placeholder={t('library.search')} value={query} onChange={event => setQuery(event.target.value)} /></label><div className="filter-tabs">{(['all', 'favorites', 'recent'] as const).map(item => <button key={item} className={filter === item ? 'is-active' : ''} onClick={() => setFilter(item)}>{item === 'favorites' ? <Star size={15} /> : item === 'recent' ? <Clock size={15} /> : <FolderOpen size={15} />}{t(`library.${item}`)}</button>)}</div></div>
    {filtered.length === 0 ? <EmptyState icon={<FolderOpen size={32} />} title={t('library.empty')} detail={t('templates.subtitle')} action={<Button onClick={() => { store.newPlan(t('library.new')); navigate('/') }}><Plus size={17} />{t('library.new')}</Button>} /> : <div className="plan-grid">{filtered.map(plan => {
      const count = plan.sequences.reduce((total, sequence) => total + sequence.steps.length, 0)
      return <article className="plan-card" key={plan.id}>
        <button className="plan-open" onClick={async () => { await store.loadPlan(plan.id); navigate('/') }}>
          <div className="plan-mini-pitch"><span className="mini-halfway" />{plan.sequences[0].steps[0].players.slice(0, 11).map(player => <i key={player.id} style={{ left: `${player.x * 100}%`, top: `${player.y * 100}%`, background: player.teamId === 'A' ? plan.teamA.color : plan.teamB.color }} />)}</div>
          <div className="plan-card-copy"><span className="plan-category">{t(`category.${plan.category}`)} · {plan.formation}</span><h2>{plan.name}</h2><p>{plan.teamA.name}{plan.opponentName ? ` vs ${plan.opponentName}` : ''}</p><small>{count} {t('plan.steps')} · {new Intl.DateTimeFormat(language, { dateStyle: 'medium' }).format(new Date(plan.updatedAt))}</small></div>
        </button>
        <footer><IconButton label={t('plan.favorite')} active={plan.favorite} onClick={async () => { await db.plans.put({ ...plan, favorite: !plan.favorite }); await refresh() }}><Heart size={17} fill={plan.favorite ? 'currentColor' : 'none'} /></IconButton><IconButton label={t('action.rename')} onClick={() => { setRenameId(plan.id); setRenameName(plan.name) }}><Pencil size={16} /></IconButton><IconButton label={t('action.duplicate')} onClick={() => void duplicate(plan.id)}><Copy size={17} /></IconButton><IconButton label={t('action.delete')} onClick={() => setDeleteId(plan.id)}><Trash2 size={17} /></IconButton></footer>
      </article>
    })}</div>}
    <section className="current-plan-actions"><div><span className="section-kicker">{t('nav.workspace')}</span><h2>{current.name}</h2></div><div><Button onClick={() => { const name = `${current.name} — copy`; store.saveAsNew(name); navigate('/') }}><Copy size={16} />{t('action.saveAs')}</Button><Button onClick={async () => { await store.saveCurrentTemplate(current.name); toast.success(t('messages.templateSaved')) }}><Star size={16} />{t('library.saveTemplate')}</Button></div></section>
    {renameId && <Modal title={t('action.rename')} onClose={() => setRenameId(null)}><form className="form-stack" onSubmit={async event => { event.preventDefault(); const plan = plans.find(item => item.id === renameId); if (plan && renameName.trim()) { await db.plans.put({ ...plan, name: renameName.trim(), updatedAt: new Date().toISOString() }); await refresh(); if (current.id === plan.id) store.updateMetadata({ name: renameName.trim() }); setRenameId(null) } }}><label className="field"><span>{t('plan.title')}</span><input autoFocus required value={renameName} onChange={event => setRenameName(event.target.value)} /></label><Button variant="primary" type="submit">{t('action.save')}</Button></form></Modal>}
    {deleteId && <Modal title={t('library.deleteTitle')} onClose={() => setDeleteId(null)}><p className="modal-copy">{t('library.deleteBody')}</p><div className="modal-actions"><Button onClick={() => setDeleteId(null)}>{t('action.cancel')}</Button><Button variant="danger" onClick={async () => { await store.deletePlan(deleteId); setDeleteId(null); toast.success(t('messages.planDeleted')) }}><Trash2 size={16} />{t('action.delete')}</Button></div></Modal>}
  </main>
}
