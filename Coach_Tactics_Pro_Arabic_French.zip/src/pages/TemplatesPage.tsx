import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import { ArrowUpRight, LayoutTemplate, Search, ShieldAlert } from 'lucide-react'
import { scenarioTemplates, instantiateTemplate } from '@/data/templates'
import { useAppStore } from '@/store/appStore'
import { createPlan } from '@/data/factory'
import { clone, uid } from '@/lib/utils'
import type { TacticalCategory } from '@/types'
import { useT } from '@/i18n'
import { EmptyState } from '@/components/Controls'

export function TemplatesPage({ setPieces = false }: { setPieces?: boolean }) {
  const t = useT()
  const navigate = useNavigate()
  const customTemplates = useAppStore(state => state.customTemplates)
  const store = useAppStore()
  const [category, setCategory] = useState<TacticalCategory | 'all' | 'custom'>(setPieces ? 'setPieces' : 'all')
  const [query, setQuery] = useState('')
  const categories: Array<TacticalCategory | 'all' | 'custom'> = setPieces ? ['setPieces'] : ['all', 'attacking', 'defensive', 'transitions', 'setPieces', 'custom']
  const templates = useMemo(() => scenarioTemplates.filter(template => (category === 'all' || template.category === category) && t(template.nameKey).toLowerCase().includes(query.toLowerCase())), [category, query, t])
  const customs = customTemplates.filter(template => category === 'custom' && template.name.toLowerCase().includes(query.toLowerCase()))
  const openCustom = (id: string) => {
    const template = customTemplates.find(item => item.id === id); if (!template) return
    const plan = createPlan(template.name)
    const sequence = { ...clone(template.sequence), id: uid('sequence') }
    plan.sequences = [sequence]; plan.activeSequenceId = sequence.id
    store.setPlan(plan); navigate('/')
  }
  return <main className="page templates-page">
    <header className="page-heading"><div><span className="section-kicker">{setPieces ? t('nav.setPieces') : t('panel.templates')}</span><h1>{setPieces ? t('setPieces.title') : t('templates.title')}</h1><p>{setPieces ? t('setPieces.subtitle') : t('templates.subtitle')}</p></div></header>
    <div className="template-disclaimer"><ShieldAlert size={18} /><p>{t('templates.disclaimer')}</p></div>
    <div className="library-tools"><label className="search-box"><Search size={18} /><input placeholder={t('action.search')} value={query} onChange={event => setQuery(event.target.value)} /></label><div className="filter-tabs">{categories.map(item => <button key={item} className={category === item ? 'is-active' : ''} onClick={() => setCategory(item)}>{item === 'all' ? t('templates.all') : item === 'custom' ? t('templates.custom') : t(`category.${item}`)}</button>)}</div></div>
    {category !== 'custom' && <div className="template-grid">{templates.map(template => <article className="template-card" key={template.id}>
      <div className={`template-pattern pattern-${template.pattern}`}><span className="pattern-line line-a" /><span className="pattern-line line-b" /><i className="pattern-player player-a" /><i className="pattern-player player-b" /><i className="pattern-player player-c" /><i className="pattern-ball" /></div>
      <div><span className="plan-category">{t(`category.${template.category}`)}</span><h2>{t(template.nameKey)}</h2><p>{t(template.descriptionKey)}</p></div>
      <button onClick={() => { const plan = instantiateTemplate(template, t); store.setPlan(plan); store.setSettings({ pitchView: template.pitchView }); navigate('/') }}><span>{t('templates.use')}</span><ArrowUpRight size={18} /></button>
    </article>)}</div>}
    {category === 'custom' && (customs.length ? <div className="template-grid">{customs.map(template => <article className="template-card" key={template.id}><div className="custom-template-icon"><LayoutTemplate size={32} /></div><div><span className="plan-category">{t('templates.custom')}</span><h2>{template.name}</h2><p>{template.sequence.steps.length} {t('plan.steps')}</p></div><button onClick={() => openCustom(template.id)}><span>{t('templates.use')}</span><ArrowUpRight size={18} /></button></article>)}</div> : <EmptyState icon={<LayoutTemplate size={32} />} title={t('templates.empty')} detail={t('library.saveTemplate')} />)}
  </main>
}
