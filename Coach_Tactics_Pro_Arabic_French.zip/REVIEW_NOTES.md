# Review notes — Coach Tactics Pro

## Changes in this review

- Moved the Fullscreen API request to the presentation button's click handler. Browsers commonly require a direct user gesture for fullscreen requests; requesting fullscreen only from a React effect can be rejected.
- Kept presentation cleanup separate from step changes so advancing through the tactical timeline does not repeatedly request fullscreen.

## Validation status

- ZIP archive structure and required project files inspected.
- `npm ci` could not complete in the review environment because package registry DNS/network access was unavailable.
- Because dependencies could not be installed, `npm run build`, unit tests, and browser end-to-end tests could not be completed here.
- The GitHub Actions workflow is included so dependency installation, tests, production build, and GitHub Pages deployment can run in GitHub's environment after the project is pushed.

Do not consider the project fully verified until the GitHub Actions workflow succeeds.
- Reduced unnecessary full-store subscriptions in the tactical board and workspace. Animation progress updates now use the Zustand store's imperative `getState()` API for event actions instead of subscribing the whole component to every state change. The pitch still subscribes to the specific state slices needed to render animation frames.
- Attempted `npm ci --ignore-scripts --no-audit --no-fund` and `npm run build`; dependency installation timed out and the build cannot run because Vite and Node type packages were not installed. No build/test pass is claimed.


## GitHub Pages and TypeScript correction

- Fixed `src/pages/Workspace.tsx`: the Delete-key handler now stores `selectedDrawingId` in a local variable and checks it against `null` before passing it to `deleteDrawing`. This resolves TS2345 at the reported location without weakening strict TypeScript checks.
- Added a ZIP-aware GitHub Actions workflow that extracts the uploaded project archive, installs the exact locked dependencies with `npm ci`, runs unit tests, builds with the repository base path, and deploys `dist/`.
- The supplied `package.json` and `package-lock.json` already include TypeScript, Vite, vite-plugin-pwa, and Vitest. The workflow no longer installs unrelated or mismatched versions separately.
- A full local dependency install/build could not be completed in this environment because the npm install operation timed out. GitHub Actions must provide the final clean build/test verification.
