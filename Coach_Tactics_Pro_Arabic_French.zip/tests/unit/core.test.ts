import { describe, expect, it } from 'vitest'
import { formationPresets, getFormation } from '@/data/formations'
import { createPlan, createStep } from '@/data/factory'
import { scenarioTemplates, instantiateTemplate } from '@/data/templates'
import { interpolateStep, quadraticPoint } from '@/engine/animation'
import { fromBase, getViewBox, toBase } from '@/engine/coordinates'
import { tacticalPlanSchema } from '@/services/schema'
import { renderStepSvg } from '@/services/exporters'
import { defaultSettings } from '@/data/factory'
import { clone } from '@/lib/utils'

describe('formation builder', () => {
  it.each(formationPresets.map(item => [item.id, item] as const))('%s has eleven unique, in-bounds positions', (_, formation) => {
    expect(formation.positions).toHaveLength(11)
    expect(new Set(formation.positions.map(item => item.number)).size).toBe(11)
    formation.positions.forEach(item => { expect(item.x).toBeGreaterThan(0); expect(item.x).toBeLessThan(1); expect(item.y).toBeGreaterThan(0); expect(item.y).toBeLessThan(1) })
  })
  it('returns a safe default for an unknown formation', () => expect(getFormation('missing').id).toBe('4-3-3'))
})

describe('independent tactical snapshots', () => {
  it('keeps player identity while preventing edits from leaking between steps', () => {
    const plan = createPlan()
    const first = plan.sequences[0].steps[0]
    const second = clone(first)
    second.players[0].x = .5
    expect(second.players[0].id).toBe(first.players[0].id)
    expect(first.players[0].x).not.toBe(.5)
  })
  it('provides a blank step with an independent ball', () => {
    const a = createStep(); const b = createStep()
    a.ball.x = .9
    expect(b.ball.x).not.toBe(.9)
  })
  it('builds valid three-step templates with stable player IDs', () => {
    const plan = instantiateTemplate(scenarioTemplates[0], key => key)
    expect(plan.sequences[0].steps).toHaveLength(3)
    const [first, second] = plan.sequences[0].steps
    expect(second.players[0].id).toBe(first.players[0].id)
    expect(tacticalPlanSchema.safeParse(plan).success).toBe(true)
  })
  it('validates every bundled scenario', () => {
    scenarioTemplates.forEach(template => expect(tacticalPlanSchema.safeParse(instantiateTemplate(template, key => key)).success, template.id).toBe(true))
  })
})

describe('deterministic animation', () => {
  it('honors delayed player runs', () => {
    const plan = createPlan(); const from = plan.sequences[0].steps[0]; const to = clone(from)
    const id = to.players[0].id
    to.players[0].x = .8
    to.transition.playerPaths[id] = { playerId: id, delay: 1000, duration: 1000, easing: 'linear', curve: 0 }
    to.transition.duration = 2000
    expect(interpolateStep(from, to, .25).players[0].x).toBe(from.players[0].x)
    expect(interpolateStep(from, to, .75).players[0].x).toBeCloseTo((from.players[0].x + .8) / 2)
    expect(interpolateStep(from, to, 1).players[0].x).toBe(.8)
  })
  it('honors delayed curved ball movement independently', () => {
    const from = createStep(); const to = clone(from)
    from.ball = { x: .1, y: .5, visible: true, trail: true }; to.ball = { x: .9, y: .5, visible: true, trail: true }
    to.transition.duration = 2000
    to.transition.ballPath = { delay: 500, duration: 1000, easing: 'linear', curve: .25, showPath: true }
    expect(interpolateStep(from, to, .1).ball.x).toBe(.1)
    const middle = interpolateStep(from, to, .5).ball
    expect(middle.x).toBeCloseTo(.5)
    expect(middle.y).toBeGreaterThan(.5)
    expect(interpolateStep(from, to, 1).ball.x).toBe(.9)
  })
  it('is deterministic and handles stationary players', () => {
    const plan = createPlan(); const from = plan.sequences[0].steps[0]; const to = clone(from)
    const a = interpolateStep(from, to, .4); const b = interpolateStep(from, to, .4)
    expect(a).toEqual(b)
    expect(a.players[0].x).toBe(from.players[0].x)
  })
  it('computes stable curved points', () => expect(quadraticPoint({ x: 0, y: 0 }, { x: 1, y: 1 }, .5, 0)).toEqual({ x: .5, y: .5 }))
})

describe('normalized coordinates and export', () => {
  it('round-trips coordinates in both attacking directions', () => {
    const point = { x: .27, y: .73 }
    expect(fromBase(toBase(point, 'ltr'), 'ltr')).toEqual(point)
    expect(fromBase(toBase(point, 'rtl'), 'rtl').x).toBeCloseTo(point.x)
  })
  it('produces portrait and cropped view boxes', () => {
    expect(getViewBox('full', 'portrait')).toBe('0 0 680 1050')
    expect(getViewBox('penaltyArea', 'landscape')).toContain('315 550')
  })
  it('renders a self-contained SVG with escaped Arabic instructions-safe text', () => {
    const plan = createPlan(); const step = plan.sequences[0].steps[0]
    step.players[0].name = 'حارس <1>'
    const svg = renderStepSvg(step, plan, { ...defaultSettings, showLabels: true })
    expect(svg).toContain('<svg')
    expect(svg).toContain('حارس &lt;1&gt;')
    expect(svg).not.toContain('undefined')
  })
})
