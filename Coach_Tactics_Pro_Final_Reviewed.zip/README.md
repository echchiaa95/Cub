# Coach Tactics Pro

A production-oriented, offline-first football tactical board and animation studio for coaches. Built with React, strict TypeScript, Vite, SVG, Zustand, Dexie/IndexedDB, Zod, Vitest, and Playwright. No backend, account, remote API, CDN, or cloud dependency is used.

## Run locally

Requires Node.js 20 or a compatible newer LTS release.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. For a reproducible CI install, use `npm ci` with the committed `package-lock.json`.

## Production build

```bash
npm test
npm run build
npm run preview
```

`dist/` is the deployable static site. The preview server is for verification only, not production hosting.

## Core workflow

1. Choose a formation and position players by dragging. Shift-click selects multiple players.
2. Show and configure the opposing team. Drag the ball independently.
3. Select a drawing tool and drag on the pitch. Curved routes have editable control points. Use the selection tool to move, recolor, duplicate, lock, or delete drawings.
4. Add timeline steps by duplicating the current state or starting blank. Each step is an independent snapshot with stable player IDs.
5. In **Step coaching**, set transition duration, easing, ball delay/duration/curve, and selected-player run timing.
6. Play, pause, scrub, change speed, or enter presentation mode. Presentation shortcuts: Space, Left/Right, Home, and Escape.
7. Plans autosave to IndexedDB after the transaction completes. Use JSON or full backups for portability.

Built-in scenarios and set pieces are editable illustrative templates, not universal tactical advice.

## Offline use and data safety

The first visit generally requires an internet connection so the application shell, local fonts, icons, and service worker can be downloaded. Installation and offline behavior depend on browser support. After the service worker has taken control, the board, animations, templates, IndexedDB plans, and export/import tools work without network access.

Plans are stored only in this browser and do not synchronize across devices. Clearing browser data or uninstalling the application may remove them. Export regular full backups from **Settings → Local data & backups**. Application updates replace cached static assets without clearing IndexedDB.

## PNG, PDF, JSON, and backups

- **PNG** exports the visible SVG board with configurable labels, legend, trails, and selection outlines. An optional workspace capture includes the editor interface.
- **PDF** creates one landscape page per step in the active sequence. Browser canvas text shaping and bundled IBM Plex Sans Arabic are used for Arabic coaching notes.
- **JSON** exports/imports a versioned, Zod-validated plan while preserving player IDs and sequence data.
- **Full backup** includes plans, custom formations, settings, and custom templates. Restoration requires confirmation and offers a current backup first.

All operations run locally. Browser download and file APIs must be supported.

## GitHub Pages deployment

The included workflow is `.github/workflows/deploy.yml`.

1. Create a GitHub repository and push this project to its `main` branch.
2. In **Settings → Pages**, set **Source** to **GitHub Actions** (not “Deploy from a branch”).
3. Run the **Test and deploy to GitHub Pages** workflow or push to `main`.
4. The site will be available at `https://USERNAME.github.io/REPOSITORY/` after GitHub completes deployment.

The workflow checks out the repository, sets up Node 20, runs `npm ci`, executes unit tests, builds `dist/`, uploads it, and deploys with the required Pages permissions.

### Change repository name or base path

The workflow automatically sets:

```bash
VITE_BASE_PATH=/${{ github.event.repository.name }}/
```

For manual builds under a repository subpath:

```bash
VITE_BASE_PATH=/REPOSITORY/ npm run build
```

For a custom domain or root hosting, use `VITE_BASE_PATH=/`. The default local value is `./`. Asset, manifest, icon, and service-worker URLs are generated relative to this base. React Router uses hash routing, so refreshing a route does not require server rewrites or produce GitHub Pages route 404s.

No actual public deployment is claimed by this repository; deployment occurs only after the workflow runs successfully in your GitHub account.

## Tests

```bash
npm test          # Vitest unit tests
npx playwright install chromium
npm run test:e2e # production build + critical browser workflows
```

End-to-end tests use the production preview at `127.0.0.1:4173`. To verify repository-subpath hosting locally, build with `VITE_BASE_PATH=/REPOSITORY/`, serve the parent directory containing `dist` renamed to `REPOSITORY`, and open `/REPOSITORY/`.

## Project structure

- `src/components/` — SVG pitch, drawing engine, player inspector, timeline, playback, presentation, and controls
- `src/engine/` — normalized coordinates and deterministic interpolation
- `src/store/` — application, selection, history, and playback state
- `src/data/` — formations, plan factories, and bundled scenario templates
- `src/services/` — IndexedDB migrations, validation, import/export, and backups
- `src/i18n/` — complete English, French, and Arabic dictionaries
- `tests/` — unit and production-browser tests

## Browser notes

The Fullscreen API is used where supported, with the in-app presentation layout as a fallback. Pointer capture and touch cancellation are handled on the SVG board. Reduced-motion preferences shorten playback transitions. IndexedDB/storage failures are reported honestly; export work before closing if storage is unavailable.
