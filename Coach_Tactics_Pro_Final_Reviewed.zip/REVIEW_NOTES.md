# Review notes — Coach Tactics Pro

## Changes in this review

- Moved the Fullscreen API request to the presentation button's click handler. Browsers commonly require a direct user gesture for fullscreen requests; requesting fullscreen only from a React effect can be rejected.
- Kept presentation cleanup separate from step changes so advancing through the tactical timeline does not repeatedly request fullscreen.

## Validation status

- ZIP archive structure and required project files inspected.
- `npm ci` could not complete in the review environment because package registry DNS/network access was unavailable.
- Because dependencies could not be installed, `npm run build`, unit tests, and browser end-to-end tests could not be completed here.
- The GitHub Actions workflow is included so dependency installation, tests, production build, and GitHub Pages deployment can run in GitHub's environment after the project is pushed.

Do not consider the project fully verified until the GitHub Actions workflow succeeds.
- Reduced unnecessary full-store subscriptions in the tactical board and workspace. Animation progress updates now use the Zustand store's imperative `getState()` API for event actions instead of subscribing the whole component to every state change. The pitch still subscribes to the specific state slices needed to render animation frames.
- Attempted `npm ci --ignore-scripts --no-audit --no-fund` and `npm run build`; dependency installation timed out and the build cannot run because Vite and Node type packages were not installed. No build/test pass is claimed.
